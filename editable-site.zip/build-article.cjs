const fs=require('fs'),path=require('path');
let JSDOM;try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom'))}
const root=__dirname,dist=path.join(root,'dist');
fs.mkdirSync(path.join(dist,'assets'),{recursive:true});
if(fs.existsSync(path.join(root,'base-assets')))fs.cpSync(path.join(root,'base-assets'),path.join(dist,'assets'),{recursive:true});
const src=new JSDOM(fs.readFileSync(path.join(root,'source/index.html'),'utf8')),source=src.window.document;
const d=new JSDOM(fs.readFileSync(path.join(root,'source/reference.html'),'utf8')).window.document;
const reportMeta=JSON.parse(fs.readFileSync(path.join(root,'site-meta.json'),'utf8'));
const {origin,title:reportTitle,releaseDate,readingMinutes}=reportMeta;
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=e=>e?e.textContent.replace(/\s+/g,' ').trim():'';
// Only colours change; the original geometry, type, grids and inline styles remain.
const palette={'#141414':'#0E1014','#2b2b2a':'#303B52','#5a5a57':'#505C7A','#2e5634':'#15254E','#4f7b56':'#53658E','#93b399':'#A8B5D1','#e3ede2':'#EFF0F3','#e2e2de':'#DCDEE4','#d6d6d2':'#B9BECA','#f3f3f0':'#F4F5F7','#b7babd':'#B9BECA','#9da1a5':'#8D99B3','#fafbfa':'#F4F5F7'};
const colour=s=>s.replace(/#[0-9a-f]{6}\b/gi,h=>palette[h.toLowerCase()]||h);
let baseCSS=[...source.querySelectorAll('style')].filter(s=>s.id!=='feedback-v2-layout').map(s=>s.textContent).join('\n')+'\n'+fs.readFileSync(path.join(root,'feedback-v2.css'),'utf8');
baseCSS=baseCSS.replace(/@font-face\s*\{[^}]*font-family:\s*'JetBrains Mono'[^}]*\}/g,'').replace(/'JetBrains Mono'(?:,\s*ui-monospace)?(?:,\s*monospace)?/g,'var(--sans)');
baseCSS=baseCSS.replace(/\.frame,\.frame \*\{animation:none!important;transition:none!important\}/g,'');
const fontCSS=[...baseCSS.matchAll(/@font-face\s*\{[^}]+\}/g)].map(m=>m[0]).join('\n');
fs.writeFileSync(path.join(dist,'assets/slide-fonts.css'),fontCSS);
const override=`
html,body{margin:0!important;padding:0!important;width:1600px!important;height:720px!important;background:var(--paper)!important}
body{font-family:var(--sans);color:var(--ink)}
.frame{margin:0!important;box-shadow:none!important}
.frame .cap,.frame .jk-fn,.frame .srcs{display:none!important}
@media print{@page{size:1600px 720px;margin:0}html,body{width:1600px!important;height:720px!important}.frame{break-after:page}}
`;
const slideCSS=colour(baseCSS)+override;
const svgCSS=slideCSS+'\n.frame{font-family:var(--sans);color:var(--ink);line-height:normal}';
const all=[...source.querySelectorAll('section.frame')];
const appendixAt=all.findIndex(s=>s.id==='appx');
const retained=all.slice(0,appendixAt).filter(s=>!['cover','contents'].includes(s.id));
const retainedIds=new Set(retained.map(s=>s.id)),slidesOut=[];
fs.rmSync(path.join(dist,'slides'),{recursive:true,force:true});
fs.rmSync(path.join(dist,'downloads'),{recursive:true,force:true});
for(const p of ['slides','downloads/svg','downloads/html'])fs.mkdirSync(path.join(dist,p),{recursive:true});
const frameScript=fs.readFileSync(path.join(root,'slide-runtime.js'),'utf8');
const themeColours={'#0e1014':'var(--ink)','#141414':'var(--ink)','#303b52':'var(--ink-2)','#2b2b2a':'var(--ink-2)','#505c7a':'var(--muted)','#5a5a57':'var(--muted)','#ffffff':'var(--paper)','#f4f5f7':'var(--canvas)','#b9beca':'var(--grey)','#dcdee4':'var(--rule-soft)','#eff0f3':'var(--tint)','#15254e':'var(--acc)','#53658e':'var(--chart-mid)','#a8b5d1':'var(--chart-light)'};
const themeValue=v=>v.replace(/#[0-9a-f]{6}\b/gi,h=>themeColours[h.toLowerCase()]||h);
function standalone(s,title){return `<!doctype html><html lang="en" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=1600"><title>${esc(title)} · Khala Research</title><style>${slideCSS}</style></head><body>${s.outerHTML}<script>${frameScript}</script></body></html>`}
for(const original of retained){
 const s=original.cloneNode(true),id=s.id;
 s.querySelectorAll('.cap,.jk-fn,.srcs,.review-date').forEach(e=>e.remove());
 s.querySelectorAll('a[href^="#"]').forEach(a=>{if(!retainedIds.has(a.hash.slice(1))){const span=source.createElement('span');span.innerHTML=a.innerHTML;a.replaceWith(span)}});
 s.querySelectorAll('.eyebrow,.kick,.exsn').forEach(e=>{e.textContent=e.textContent.replace(/\b0([1-9])\b/g,'$1')});
 for(const e of [s,...s.querySelectorAll('*')])for(const a of [...e.attributes])if(['fill','stroke','style'].includes(a.name))e.setAttribute(a.name,colour(a.value));
 for(const e of s.querySelectorAll('svg.chart *,svg.ffsvg *,svg.exmini *'))for(const a of [...e.attributes])if(['fill','stroke','style'].includes(a.name))e.setAttribute(a.name,themeValue(a.value));
 const title=text(original.querySelector('header h2,.actl h2,.jk-intro h1'))||original.dataset.title;
 const html=standalone(s,title);fs.writeFileSync(path.join(dist,'slides',id+'.html'),html);fs.writeFileSync(path.join(dist,'downloads/html',id+'.html'),html);
 const xhtml=new src.window.XMLSerializer().serializeToString(s);
 const svg=`<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="1600" height="720" viewBox="0 0 1600 720" role="img" aria-label="${esc(title)}"><title>${esc(title)}</title><foreignObject x="0" y="0" width="1600" height="720"><div xmlns="http://www.w3.org/1999/xhtml"><style><![CDATA[${svgCSS}]]></style>${xhtml}</div></foreignObject></svg>`;
 fs.writeFileSync(path.join(dist,'downloads/svg',id+'.svg'),svg);
 slidesOut.push({id,title,originalIndex:all.indexOf(original)+1,html:'downloads/html/'+id+'.html',svg:'downloads/svg/'+id+'.svg',frame:'slides/'+id+'.html',divider:s.classList.contains('act')});
}
const groups=[{id:'executive-summary',title:'Executive summary',ids:['summary']},{id:'case-for-privacy',title:'The case for privacy',num:1,ids:['act1','capital','founders','policy','usecases','priced']},{id:'value-capture',title:'Value capture across the coverage universe',num:2,ids:['act2','tokens','zcash','aztec','umbra','venice']},{id:'network-privacy',title:'SN25 UR and the network privacy opportunity',num:3,ids:['act3','edges','mau','sn25','operators','bull','value','pipeline','watch','catalysts']}];
function card(id,prefix=''){
 const e=slidesOut.find(e=>e.id===id);
 return `<figure class="privacy-slide ${e.divider?'privacy-divider':''}" id="${id}" data-source-slide="${e.originalIndex}"><div class="privacy-slide-viewport"><iframe src="${prefix+e.frame}" width="1600" height="720" title="${esc(e.title)}" loading="${id==='summary'?'eager':'lazy'}" scrolling="no"></iframe></div><figcaption><span class="privacy-slide-title">${esc(e.title)}</span><span class="privacy-slide-actions"><a href="${prefix+e.svg}" download="khala-${id}.svg" aria-label="Download SVG: ${esc(e.title)}">SVG ↓</a><a href="${prefix+e.html}" data-expand-slide="${id}" aria-label="Expand: ${esc(e.title)}">Expand ↗</a></span></figcaption></figure>`;
}
// Retain Khala's actual article chrome and the reference byline verbatim.
d.title=reportTitle+' · Khala Research';
const revision=d.createElement('meta');revision.name='khala-build';revision.content='2026-10-18-jack-v4';d.head.append(revision);
d.querySelector('meta[name="description"]').content='What privacy networks sell, who pays, and how value reaches Zcash, Aztec, Umbra, Venice and SN25 UR.';
for(const e of d.querySelectorAll('script[type="application/ld+json"],link[rel="canonical"],link[rel="alternate"][type="text/markdown"],meta[property^="og:"],meta[name^="twitter:"]'))e.remove();
for(const e of d.querySelectorAll('script[src*="cloudflareinsights"]'))e.remove();
const initialScript=d.head.querySelector('script');initialScript.textContent=initialScript.textContent.replace("t=window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'","t='light'");
for(const f of ['slide-fonts.css','privacy.css']){const l=d.createElement('link');l.rel='stylesheet';l.href='assets/'+f;d.head.append(l)}
d.querySelector('.r-title').textContent=reportTitle;
d.querySelector('.r-deck').textContent=text(source.querySelector('#cover .sub'))||'Demand for on-chain privacy is established. Whether it accrues to token holders depends on what each network sells, who pays for it, and where that value ends up.';
d.querySelector('.k-tags').innerHTML='<time class="k-tag" datetime="'+releaseDate+'">November 2, 2026</time><span class="k-tag">Privacy</span><span class="k-tag">'+readingMinutes+' min read</span>';
const downloads=d.createElement('div');downloads.className='privacy-downloads';downloads.innerHTML='<a class="k-btn k-btn--sm" href="deck/">View slide deck ↗</a><a class="privacy-deck-link" href="downloads/khala-slides.zip" download>Download all slides ↓</a>';
d.querySelector('.k-byline').after(downloads);
d.querySelector('.r-cover').innerHTML='<img fetchpriority="high" decoding="async" src="assets/pricing-privacy.png" alt="'+esc(reportTitle)+' — Khala Research" width="1774" height="887">';
d.querySelector('.r-body').innerHTML=groups.map(g=>`<section class="r-section" id="${g.id}"><h2 class="r-h2">${g.num?`<span class="k-label">${g.num}</span>`:''}${esc(g.title)}</h2>${g.ids.map(id=>card(id)).join('')}</section>`).join('');
d.querySelector('.r-toc ol').innerHTML=groups.map(g=>`<li><a href="#${g.id}" data-toc="${g.id}">${g.num?`<span class="k-label">${g.num}</span>`:''}${esc(g.title)}</a></li>`).join('');
for(const a of d.querySelectorAll('a[href^="/"]'))a.setAttribute('href','https://www.khala.io'+a.getAttribute('href'));
for(const a of d.querySelectorAll('[data-telegram-link]'))a.href='https://t.me/KhalaReads';
d.querySelectorAll('.r-back').forEach(a=>a.href='https://www.khala.io/research');
const dialog=d.createElement('dialog');dialog.id='privacy-slide-dialog';dialog.className='privacy-slide-dialog';dialog.setAttribute('aria-label','Expanded research slide');dialog.innerHTML='<div class="privacy-dialog-bar"><span data-expanded-title>Khala Research</span><div><a data-expanded-svg download>Download SVG ↓</a><a data-expanded-html download>Download expanded HTML ↓</a><button data-close-slide type="button">Close ×</button></div></div><div class="privacy-expanded-scroll"><div class="privacy-slide-viewport privacy-expanded-viewport"></div></div>';d.body.append(dialog);
const script=d.createElement('script');script.src='assets/privacy.js';d.body.append(script);
const canonical=d.createElement('link');canonical.rel='canonical';canonical.href=origin+'/';d.head.append(canonical);
for(const [name,value] of Object.entries({'og:title':reportTitle+' · Khala Research','og:description':d.querySelector('meta[name="description"]').content,'og:type':'article','og:site_name':'Khala Research','og:url':origin+'/','og:image':origin+'/assets/pricing-privacy.png'})){const m=d.createElement('meta');m.setAttribute('property',name);m.content=value;d.head.append(m)}
require('./agent-readable.cjs')({document:d,slides:retained,meta:reportMeta,dist});
fs.writeFileSync(path.join(dist,'index.html'),'<!doctype html>\n'+d.documentElement.outerHTML);
fs.writeFileSync(path.join(dist,'slides.json'),JSON.stringify(slidesOut,null,2));fs.mkdirSync(path.join(dist,'deck'),{recursive:true});
fs.writeFileSync(path.join(dist,'deck/index.html'),`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(reportTitle)} · Slides</title><link rel="stylesheet" href="../assets/khala.css"><link rel="stylesheet" href="../assets/privacy.css"></head><body class="privacy-deck-page"><nav class="privacy-deck-nav"><a href="../">← Back to report</a><span>${esc(reportTitle)} · Khala Research</span><a href="../downloads/khala-slides.zip" download>Download all slides ↓</a></nav><main>${slidesOut.map(e=>card(e.id,'../')).join('')}</main><script src="../assets/privacy.js"></script></body></html>`);
fs.copyFileSync(path.join(root,'source/og.png'),path.join(dist,'assets/pricing-privacy.png'));
const jsPath=path.join(dist,'assets/khala.js');let js=fs.readFileSync(jsPath,'utf8');js=js.replace('  initServiceWorker();','  // Service worker belongs to khala.io.').replace('  initFigureExport();','  // Exports are static, self-contained files.');fs.writeFileSync(jsPath,js);
fs.writeFileSync(path.join(root,'content-map.json'),JSON.stringify({reference:'https://www.khala.io/age-of-machines-learning-problem-robot-training-data-physical-ai',authors:['0xSammy','Jack Ai-Leung'],sourceSlides:all.length,retainedSlides:slidesOut.length,removed:all.slice(appendixAt).map(s=>s.id),slidesOut},null,2));
console.log(JSON.stringify({slides:slidesOut.length,sections:groups.length,charts:retained.reduce((n,s)=>n+s.querySelectorAll('svg.chart').length,0),bytes:fs.statSync(path.join(dist,'index.html')).size}));
