"""Compose the thumbnail with Khala's real Inter Tight font and original logo."""
from pathlib import Path
from base64 import b64encode
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.varLib.instancer import instantiateVariableFont
import xml.etree.ElementTree as ET

root=Path(__file__).parent
font=TTFont(root/'base-assets/fonts/inter-tight-latin.woff2')
if 'fvar' in font:font=instantiateVariableFont(font,{'wght':400},inplace=False)
glyphs=font.getGlyphSet();cmap=font.getBestCmap();upm=font['head'].unitsPerEm
lines=['PRIVACY:','WHO CAPTURES','THE VALUE?']
def width(text):return sum(glyphs[cmap[ord(c)]].width for c in text)/upm
size=min(92,600/max(map(width,lines)))
paths=[]
for line,baseline in zip(lines,[235,340,445]):
 x=64
 for char in line:
  name=cmap[ord(char)];pen=SVGPathPen(glyphs)
  glyphs[name].draw(TransformPen(pen,(size/upm,0,0,-size/upm,x,baseline)))
  p=pen.getCommands()
  if p:paths.append('<path d="'+p+'"/>')
  x+=glyphs[name].width*size/upm-size*.018
logo=ET.fromstring((root/'base-assets/logo.svg').read_text())
for e in logo.iter():
 if e.get('fill') and e.get('fill')!='none':e.set('fill','#FFFFFF')
logo_content=''.join(ET.tostring(c,encoding='unicode') for c in logo)
picture=b64encode((root/'source/cover-background.png').read_bytes()).decode()
svg='<svg xmlns="http://www.w3.org/2000/svg" width="1774" height="887" viewBox="0 0 1774 887" role="img" aria-label="Privacy: Who Captures the Value? — Khala Research"><title>Privacy: Who Captures the Value?</title><image href="data:image/png;base64,'+picture+'" width="1774" height="887"/><g fill="#FFFFFF">'+''.join(paths)+'</g><g fill="#FFFFFF" transform="translate(64 690) scale(2.12)">'+logo_content+'</g></svg>'
(root/'source/cover.svg').write_text(svg)
print('Inter Tight 400; headline size:',round(size,2))
