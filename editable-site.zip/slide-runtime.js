(function(){
 'use strict';
 var root=document.documentElement,frame=document.querySelector('.frame');
 var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 function theme(t){root.dataset.theme=t==='dark'?'dark':'light'}
 try{theme(parent!==window?parent.document.documentElement.dataset.theme:localStorage.getItem('khala-theme'))}catch(e){theme('light')}
 window.addEventListener('message',function(e){if(e.source===parent&&e.data&&e.data.type==='khala-theme')theme(e.data.theme)});
 var tip=document.createElement('div');tip.className='tip';tip.id='slide-tooltip';tip.setAttribute('role','tooltip');document.body.append(tip);
 var owner=null;
 function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML}
 function place(x,y){var pad=16,w=tip.offsetWidth,h=tip.offsetHeight,nx=x+pad,ny=y+pad;if(nx+w>innerWidth-12)nx=x-w-pad;if(ny+h>innerHeight-12)ny=y-h-pad;tip.style.left=Math.max(12,nx)+'px';tip.style.top=Math.max(12,ny)+'px'}
 function hide(){if(owner){var f=owner.closest('.fig');if(f)f.classList.remove('hovering');owner.classList.remove('hot');owner.removeAttribute('aria-describedby')}owner=null;tip.classList.remove('on')}
 function show(t,x,y){hide();owner=t;var p=(t.dataset.tip||'').split('||');tip.innerHTML='<b>'+esc(p[0]||'')+'</b>'+(p[1]?esc(p[1]):'')+(p[2]?'<i>'+esc(p[2])+'</i>':'');tip.classList.add('on');t.setAttribute('aria-describedby',tip.id);place(x,y);var f=t.closest('.fig');if(f){f.classList.add('hovering');t.classList.add('hot')}}
 document.querySelectorAll('[data-tip]').forEach(function(e){e.removeAttribute('title')});
 document.addEventListener('pointerover',function(e){if(e.pointerType&&e.pointerType!=='mouse')return;var t=e.target.closest&&e.target.closest('[data-tip]');if(t&&t!==owner)show(t,e.clientX,e.clientY);else if(!t)hide()});
 document.addEventListener('pointermove',function(e){if(owner&&e.pointerType==='mouse')place(e.clientX,e.clientY)});
 document.addEventListener('pointerleave',hide);
 document.addEventListener('focusin',function(e){var t=e.target.closest&&e.target.closest('[data-tip]');if(t){var r=t.getBoundingClientRect();show(t,r.left+r.width/2,r.bottom)}});
 document.addEventListener('focusout',hide);
 document.addEventListener('keydown',function(e){if(e.key==='Escape')hide()});
 document.addEventListener('click',function(e){
  var go=e.target.closest&&e.target.closest('a[href^="#"],[data-go]');
  if(go){e.preventDefault();var id=go.dataset.go||go.hash.slice(1);if(parent!==window)parent.postMessage({type:'khala-anchor',id:id},'*');else document.getElementById(id)?.scrollIntoView();return}
  var toggle=e.target.closest&&e.target.closest('[data-toggle]');if(toggle){var ledger=frame.querySelector('.ledger')||frame;var on=ledger.classList.toggle('reveal');toggle.setAttribute('aria-pressed',String(on));return}
  var t=e.target.closest&&e.target.closest('[data-tip]');if(t&&matchMedia('(hover: none)').matches){if(owner===t)hide();else{var r=t.getBoundingClientRect();show(t,r.left+r.width/2,r.bottom)}}
 });
 document.querySelectorAll('.cover,.act').forEach(function(c){var pl=c.querySelector('.plates');if(!pl)return;c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect();pl.style.setProperty('--px',((e.clientX-r.left)/r.width-.5).toFixed(3));pl.style.setProperty('--py',((e.clientY-r.top)/r.height-.5).toFixed(3))});c.addEventListener('pointerleave',function(){pl.style.setProperty('--px',0);pl.style.setProperty('--py',0)})});
 function count(el){var to=parseFloat(el.dataset.count),start=performance.now();function draw(t){var k=Math.min(1,(t-start)/1100),v=to*(1-Math.pow(1-k,3)),dp=+(el.dataset.dp||0),s=el.dataset.sep?Math.round(v).toLocaleString('en-AU'):v.toFixed(dp);el.textContent=(el.dataset.pre||'')+s+(el.dataset.suf||'');if(k<1)requestAnimationFrame(draw)}requestAnimationFrame(draw)}
 function play(){frame.classList.add('play');if(!reduce)frame.querySelectorAll('.num[data-count]').forEach(count)}
 if(!reduce&&'IntersectionObserver'in window){var io=new IntersectionObserver(function(es){if(es.some(function(e){return e.isIntersecting})){play();io.disconnect()}},{threshold:.25});io.observe(frame)}
})();
