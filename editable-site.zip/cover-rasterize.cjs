const fs=require('fs'),path=require('path');
let sharp;try{sharp=require('sharp')}catch{sharp=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'sharp'))}
sharp(fs.readFileSync(path.join(__dirname,'source/cover.svg'))).png().toFile(path.join(__dirname,'source/og.png')).then(()=>console.log('Rendered the exact-font thumbnail.'));
