const fs=require('fs'),path=require('path');let JSDOM;try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom'))}
const root=__dirname,dist=path.join(root,'dist'),out=path.resolve(process.argv[2]||path.join(root,'github'));fs.mkdirSync(out,{recursive:true});
const dom=new JSDOM(fs.readFileSync(path.join(dist,'index.html'),'utf8')),d=dom.window.document;
const types={'.woff2':'font/woff2','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.jpg':'image/jpeg'};
const data=p=>'data:'+(types[path.extname(p)]||'application/octet-stream')+';base64,'+fs.readFileSync(p).toString('base64');
const cssFile=p=>fs.readFileSync(p,'utf8').replace(/url\((['"]?)([^)'"\s]+)\1\)/g,(m,q,u)=>{if(/^(data:|https?:|#)/.test(u))return m;const target=path.resolve(path.dirname(p),u);return fs.existsSync(target)?'url("'+data(target)+'")':m});
for(const l of [...d.querySelectorAll('link[rel="stylesheet"]')]){const s=d.createElement('style');s.textContent=cssFile(path.join(dist,l.getAttribute('href').split('?')[0]));l.replaceWith(s)}
for(const e of d.querySelectorAll('img[src],link[rel*="icon"][href]')){const a=e.tagName==='IMG'?'src':'href',v=e.getAttribute(a);if(v&&!/^(https?:|data:)/.test(v)){const p=path.join(dist,v);if(fs.existsSync(p))e.setAttribute(a,data(p))}}
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'slides.json'),'utf8'));
let sharedCSS='';const slides=manifest.map(s=>{const sd=new JSDOM(fs.readFileSync(path.join(dist,s.frame),'utf8')).window.document;if(!sharedCSS)sharedCSS=sd.querySelector('style').textContent;return {...s,body:sd.body.innerHTML.replace(/location\.origin/g,'parent.location.origin')}});
const payload=d.createElement('script');payload.type='application/json';payload.id='khala-slide-data';payload.textContent=JSON.stringify({css:sharedCSS,slides}).replace(/</g,'\\u003c');d.body.append(payload);
for(const f of d.querySelectorAll('.privacy-slide iframe')){f.removeAttribute('src');f.dataset.slideId=f.closest('.privacy-slide').id}
for(const a of d.querySelectorAll('a[href="downloads/khala-slides.zip"]'))a.href='khala-slides.zip';
for(const a of d.querySelectorAll('a[href="deck/"]')){a.href='#deck';a.setAttribute('data-view-deck','')}
d.querySelectorAll('link[rel="preload"]').forEach(e=>e.remove());
for(const e of d.querySelectorAll('meta[property="og:image"]'))e.content='https://kdotpham.github.io/khala-privacy-reviewed/og.png?v=3';
const button=d.createElement('button');button.className='privacy-deck-return';button.textContent='Back to article';button.setAttribute('type','button');d.body.append(button);
const extra=d.createElement('style');extra.textContent='.privacy-deck-return{display:none}.privacy-deck-mode .privacy-deck-return{display:block;position:fixed;right:20px;top:16px;z-index:999;background:var(--k-bg);color:var(--k-ink);border:1px solid var(--k-line);padding:10px 16px;font:13px var(--k-font)}.privacy-deck-mode .k-announce,.privacy-deck-mode .k-nav,.privacy-deck-mode .r-hero,.privacy-deck-mode .r-rail,.privacy-deck-mode footer,.privacy-deck-mode .r-subbar{display:none!important}.privacy-deck-mode .r-layout.k-wrap{display:block;width:calc(100% - 32px);max-width:1600px;padding-top:64px}.privacy-deck-mode .r-body{width:100%}';d.head.append(extra);
const runtime=`(function(){
const data=JSON.parse(document.getElementById('khala-slide-data').textContent);
for(const s of data.slides){
 const html='<!doctype html><html lang="en" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=1600"><title>'+s.title.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</title><style>'+data.css+'</style></head><body>'+s.body+'</body></html>';
 const doc=new DOMParser().parseFromString(html,'text/html'),section=doc.querySelector('section.frame');
 const svg='<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="720" viewBox="0 0 1600 720"><title>'+s.title.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</title><foreignObject width="1600" height="720"><div xmlns="http://www.w3.org/1999/xhtml"><style><![CDATA['+data.css+']]></style>'+new XMLSerializer().serializeToString(section)+'</div></foreignObject></svg>';
 const hu=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),su=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'})),fig=document.getElementById(s.id);
 fig.querySelector('iframe').srcdoc=html;fig.querySelector('[download]').href=su;fig.querySelector('[data-expand-slide]').href=hu;
}
})();`;
for(const s of [...d.querySelectorAll('script[src]')]){
 const file=s.getAttribute('src').split('?')[0],v=fs.readFileSync(path.join(dist,file),'utf8');
 if(file.endsWith('privacy.js')){const prep=d.createElement('script');prep.textContent=runtime;s.before(prep)}
 s.removeAttribute('src');s.textContent=v;
}
// Payload must exist before the runtime prepares its frames.
const runtimeNode=[...d.scripts].find(s=>s.textContent===runtime);runtimeNode.before(payload);
fs.writeFileSync(path.join(out,'index.html'),'<!doctype html>\n'+d.documentElement.outerHTML);
fs.copyFileSync(path.join(dist,'downloads/khala-slides.zip'),path.join(out,'khala-slides.zip'));
fs.copyFileSync(path.join(dist,'assets/pricing-privacy.png'),path.join(out,'og.png'));
fs.writeFileSync(path.join(out,'.nojekyll'),'');
for(const f of ['report.html','report.md','report.json','llms.txt'])fs.copyFileSync(path.join(dist,f),path.join(out,f));
console.log(JSON.stringify({indexBytes:fs.statSync(path.join(out,'index.html')).size,slides:slides.length,folder:out}));
