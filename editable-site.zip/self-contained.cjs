const fs=require('fs'),path=require('path');let JSDOM;try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom'))}
const root=__dirname,dist=path.join(root,'dist'),out=path.resolve(process.argv[2]||path.join(root,'github'));fs.mkdirSync(out,{recursive:true});
const dom=new JSDOM(fs.readFileSync(path.join(dist,'index.html'),'utf8')),d=dom.window.document;
const types={'.woff2':'font/woff2','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.jpg':'image/jpeg'};
const data=p=>'data:'+(types[path.extname(p)]||'application/octet-stream')+';base64,'+fs.readFileSync(p).toString('base64');
const cssFile=p=>fs.readFileSync(p,'utf8').replace(/url\((['"]?)([^)'"\s]+)\1\)/g,(m,q,u)=>{if(/^(data:|https?:|#)/.test(u))return m;const target=path.resolve(path.dirname(p),u);return fs.existsSync(target)?'url("'+data(target)+'")':m});
for(const l of [...d.querySelectorAll('link[rel="stylesheet"]')]){const s=d.createElement('style');s.textContent=cssFile(path.join(dist,l.getAttribute('href').split('?')[0]));l.replaceWith(s)}
for(const e of d.querySelectorAll('img[src],link[rel*="icon"][href]')){const a=e.tagName==='IMG'?'src':'href',v=e.getAttribute(a);if(v&&!/^(https?:|data:)/.test(v)){const p=path.join(dist,v);if(fs.existsSync(p))e.setAttribute(a,data(p))}}
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'slides.json'),'utf8'));
let sharedCSS='';const slides=manifest.map(s=>{const sd=new JSDOM(fs.readFileSync(path.join(dist,s.frame),'utf8')).window.document;if(!sharedCSS)sharedCSS=sd.querySelector('style').textContent;return {...s,body:sd.body.innerHTML.replace(/location\.origin/g,'parent.location.origin')}});
const payload=d.createElement('script');payload.type='application/json';payload.id='khala-slide-data';payload.textContent=JSON.stringify({css:sharedCSS,slides}).replace(/</g,'\\u003c');d.body.append(payload);
for(const f of d.querySelectorAll('.privacy-slide iframe')){f.removeAttribute('src');f.dataset.slideId=f.closest('.privacy-slide').id}
for(const a of d.querySelectorAll('a[href="downloads/khala-slides.zip"]'))a.href='khala-slides.zip';
for(const a of d.querySelectorAll('a[href="deck/"]')){a.href='#deck';a.setAttribute('data-view-deck','')}
d.querySelectorAll('link[rel="preload"]').forEach(e=>e.remove());
for(const e of d.querySelectorAll('meta[property="og:image"]'))e.content='https://kdotpham.github.io/khala-privacy-reviewed/og.png?v=3';
const button=d.createElement('button');button.className='privacy-deck-return';button.textContent='Back to article';button.setAttribute('type','button');d.body.append(button);
const extra=d.createElement('style');extra.textContent='.privacy-deck-return{display:none}.privacy-deck-mode .privacy-deck-return{display:block;position:fixed;right:20px;top:16px;z-index:999;background:var(--k-bg);color:var(--k-ink);border:1px solid var(--k-line);padding:10px 16px;font:13px var(--k-font)}.privacy-deck-mode .k-announce,.privacy-deck-mode .k-nav,.privacy-deck-mode .r-hero,.privacy-deck-mode .r-rail,.privacy-deck-mode footer,.privacy-deck-mode .r-subbar{display:none!important}.privacy-deck-mode .r-layout.k-wrap{display:block;width:calc(100% - 32px);max-width:1600px;padding-top:64px}.privacy-deck-mode .r-body{width:100%}';d.head.append(extra);
const runtime=`(function(){
const data=JSON.parse(document.getElementById('khala-slide-data').textContent);
var KX=[];
function kxMobile(){return window.innerWidth<=760||window.innerHeight<=500}
function kxOpenMobile(start,opener){
 var idx=start,y=window.scrollY,dark=(document.documentElement.getAttribute('data-theme')||'light')==='dark';
 var ov=document.createElement('div');ov.className='kx-m';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');
 ov.innerHTML='<div class="kx-m-bar"><span class="kx-m-count"></span><button type="button" class="kx-m-close" aria-label="Close full size view">Close</button></div><div class="kx-m-area"><div class="kx-m-slide"><div class="kx-m-inner"><iframe width="1600" height="720" scrolling="no" tabindex="-1"></iframe></div></div><p class="kx-m-hint">Rotate or pinch to zoom</p></div><div class="kx-m-nav"><button type="button" class="kx-m-prev">Previous</button><button type="button" class="kx-m-next">Next</button></div>';
 var area=ov.querySelector('.kx-m-area'),box=ov.querySelector('.kx-m-slide'),inner=ov.querySelector('.kx-m-inner'),fr=ov.querySelector('iframe'),hint=ov.querySelector('.kx-m-hint'),cnt=ov.querySelector('.kx-m-count');
 var base=1,z=1,tx=0,ty=0;
 function apply(){inner.style.transform='translate('+tx+'px,'+ty+'px) scale('+z+')'}
 function clampPan(){var w=1600*base,h=720*base;var mx=Math.max(0,(w*z-w)/2),my=Math.max(0,(h*z-h)/2);tx=Math.max(-mx,Math.min(mx,tx));ty=Math.max(-my,Math.min(my,ty))}
 function fit(){var land=window.innerWidth>window.innerHeight;ov.classList.toggle('is-land',land);
  var aw=area.clientWidth-(land?0:24),ah=area.clientHeight-(land?0:40);base=Math.min(aw/1600,ah/720);
  fr.style.transform='scale('+base+')';box.style.width=(1600*base)+'px';box.style.height=(720*base)+'px';inner.style.width=box.style.width;inner.style.height=box.style.height;z=1;tx=0;ty=0;apply()}
 function show(i){idx=(i+KX.length)%KX.length;var s=KX[idx];cnt.textContent='Slide '+(idx+1)+' of '+KX.length;ov.setAttribute('aria-label',s.title);fr.title=s.title;fr.srcdoc=dark?s.html.replace('data-theme="light"','data-theme="dark"'):s.html;
  ov.querySelector('.kx-m-prev').disabled=idx===0;ov.querySelector('.kx-m-next').disabled=idx===KX.length-1;z=1;tx=0;ty=0;apply()}
 function close(){window.removeEventListener('resize',fit);document.removeEventListener('keydown',key);ov.remove();document.documentElement.style.overflow='';document.body.style.overflow='';window.scrollTo({top:y,behavior:'instant'});if(opener)opener.focus({preventScroll:true})}
 function key(e){if(e.key==='Escape')close();else if(e.key==='ArrowRight'&&idx<KX.length-1)show(idx+1);else if(e.key==='ArrowLeft'&&idx>0)show(idx-1)}
 ov.querySelector('.kx-m-close').addEventListener('click',close);
 ov.querySelector('.kx-m-prev').addEventListener('click',function(){if(idx>0)show(idx-1)});
 ov.querySelector('.kx-m-next').addEventListener('click',function(){if(idx<KX.length-1)show(idx+1)});
 area.addEventListener('click',function(e){if(!box.contains(e.target))close()});
 var t0=null,pinch=null,moved=false;
 function d(a,b){return Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY)}
 area.addEventListener('touchstart',function(e){moved=false;if(e.touches.length===2){pinch={d:d(e.touches[0],e.touches[1]),z:z};t0=null}else if(e.touches.length===1){t0={x:e.touches[0].clientX,y:e.touches[0].clientY,tx:tx,ty:ty}}},{passive:true});
 area.addEventListener('touchmove',function(e){if(pinch&&e.touches.length===2){e.preventDefault();z=Math.max(1,Math.min(3,pinch.z*d(e.touches[0],e.touches[1])/pinch.d));clampPan();apply();moved=true}else if(t0&&e.touches.length===1&&z>1){e.preventDefault();tx=t0.tx+e.touches[0].clientX-t0.x;ty=t0.ty+e.touches[0].clientY-t0.y;clampPan();apply();moved=true}},{passive:false});
 area.addEventListener('touchend',function(e){if(pinch&&e.touches.length<2){pinch=null;if(z<=1.02){z=1;tx=0;ty=0;apply()}return}
  if(t0&&z===1&&e.changedTouches.length){var dx=e.changedTouches[0].clientX-t0.x,dy=e.changedTouches[0].clientY-t0.y;
   if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.3){if(dx<0&&idx<KX.length-1)show(idx+1);else if(dx>0&&idx>0)show(idx-1)}
   else if(dy>90&&Math.abs(dy)>Math.abs(dx)*1.3)close()}
  t0=null},{passive:true});
 document.documentElement.style.overflow='hidden';document.body.style.overflow='hidden';
 document.body.appendChild(ov);show(idx);fit();window.addEventListener('resize',fit);document.addEventListener('keydown',key);ov.querySelector('.kx-m-close').focus({preventScroll:true});
}
for(const s of data.slides){
 const html='<!doctype html><html lang="en" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=1600"><title>'+s.title.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</title><style>'+data.css+'</style></head><body>'+s.body+'</body></html>';
 const doc=new DOMParser().parseFromString(html,'text/html'),section=doc.querySelector('section.frame');
 const svg='<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="720" viewBox="0 0 1600 720"><title>'+s.title.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</title><foreignObject width="1600" height="720"><div xmlns="http://www.w3.org/1999/xhtml"><style><![CDATA['+data.css+']]></style>'+new XMLSerializer().serializeToString(section)+'</div></foreignObject></svg>';
 const hu=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),su=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'})),fig=document.getElementById(s.id);
 fig.querySelector('iframe').srcdoc=html;
 const kxi=KX.length;KX.push({title:s.title,html:html});
 const fb=fig.querySelector('.ix-full');if(fb)fb.addEventListener('click',function(){
  if(kxMobile()){kxOpenMobile(kxi,fb);return}
  const ov=document.createElement('div');ov.className='kx-full';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label',s.title);
  ov.innerHTML='<div class=\"kx-full-bar\"><span></span><button type=\"button\" class=\"kx-full-close\" aria-label=\"Close full size view\">Close</button></div><div class=\"kx-full-scroll\"><div class=\"kx-full-stage\"><iframe width=\"1600\" height=\"720\" scrolling=\"no\"></iframe></div></div>';
  ov.querySelector('span').textContent=s.title;const fr=ov.querySelector('iframe');fr.title=s.title;
  const dark=(document.documentElement.getAttribute('data-theme')||'light')==='dark';fr.srcdoc=dark?html.replace('data-theme=\"light\"','data-theme=\"dark\"'):html;
  const stage=ov.querySelector('.kx-full-stage');
  function fit(){const vw=window.innerWidth,vh=window.innerHeight;let k=1;if(vw>=760){k=Math.min(1,(vw-48)/1600,(vh-96)/720)}fr.style.transform='scale('+k+')';stage.style.width=(1600*k)+'px';stage.style.height=(720*k)+'px'}
  fit();window.addEventListener('resize',fit);
  function close(){window.removeEventListener('resize',fit);document.removeEventListener('keydown',key);ov.remove();document.documentElement.style.overflow='';fb.focus()}
  function key(e){if(e.key==='Escape')close()}
  ov.querySelector('.kx-full-close').addEventListener('click',close);ov.addEventListener('click',function(e){if(e.target===ov||e.target.classList.contains('kx-full-scroll'))close()});document.addEventListener('keydown',key);
  document.documentElement.style.overflow='hidden';document.body.appendChild(ov);ov.querySelector('.kx-full-close').focus();
 });
 const vp=fig.querySelector('.privacy-slide-viewport');if(vp&&fb){vp.addEventListener('click',function(){if(kxMobile())fb.click()})}
 const btn=fig.querySelector('.ix-export');if(btn)btn.addEventListener('click',function(){
  const dark=(document.documentElement.getAttribute('data-theme')||'light')==='dark';
  let css=data.css;if(dark)css=css.split('html[data-theme=\"dark\"]').join('div.kx-dark');
  const wrap='<div xmlns=\"http://www.w3.org/1999/xhtml\" class=\"'+(dark?'kx-dark':'kx-light')+'\" style=\"width:1600px;height:720px;font-family:var(--sans);color:var(--ink);background:var(--paper)\"><style><![CDATA['+css+']]></style>'+new XMLSerializer().serializeToString(section)+'</div>';
  const out='<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1600\" height=\"720\" viewBox=\"0 0 1600 720\"><foreignObject width=\"1600\" height=\"720\">'+wrap+'</foreignObject></svg>';
  btn.disabled=true;btn.textContent='Exporting…';
  const img=new Image();img.onload=function(){const c=document.createElement('canvas');c.width=3200;c.height=1440;const x=c.getContext('2d');x.scale(2,2);x.drawImage(img,0,0);
   c.toBlob(function(b){const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='khala-'+s.id+'-'+(dark?'dark':'light')+'.png';document.body.appendChild(a);a.click();a.remove();btn.disabled=false;btn.textContent='Export PNG'},'image/png')};
  img.onerror=function(){btn.textContent='Export failed';setTimeout(function(){btn.disabled=false;btn.textContent='Export PNG'},1500)};
  img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(out);
 });
}
})();`;
for(const s of [...d.querySelectorAll('script[src]')]){
 const file=s.getAttribute('src').split('?')[0],v=fs.readFileSync(path.join(dist,file),'utf8');
 if(file.endsWith('privacy.js')){const prep=d.createElement('script');prep.textContent=runtime;s.before(prep)}
 s.removeAttribute('src');s.textContent=v;
}
// Payload must exist before the runtime prepares its frames.
const runtimeNode=[...d.scripts].find(s=>s.textContent===runtime);runtimeNode.before(payload);
fs.writeFileSync(path.join(out,'index.html'),'<!doctype html>\n'+d.documentElement.outerHTML);
fs.copyFileSync(path.join(dist,'downloads/khala-slides.zip'),path.join(out,'khala-slides.zip'));
fs.copyFileSync(path.join(dist,'assets/pricing-privacy.png'),path.join(out,'og.png'));
fs.writeFileSync(path.join(out,'.nojekyll'),'');
for(const f of ['report.html','report.md','report.json','llms.txt'])fs.copyFileSync(path.join(dist,f),path.join(out,f));
console.log(JSON.stringify({indexBytes:fs.statSync(path.join(out,'index.html')).size,slides:slides.length,folder:out}));
