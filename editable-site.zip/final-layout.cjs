const fs=require('fs'),{JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom'),p=__dirname+'/source/index.html',d=new JSDOM(fs.readFileSync(p,'utf8')).window.document;
const style=d.createElement('style');style.textContent=`
.frame.L-top>.body{height:502px}.frame.L-top>.body>.main{height:502px}
#capital .main{width:1134px;flex:none}#capital .main>svg.chart{width:1134px;height:500px;flex:none}
#policy .main{width:1504px;flex:none}#policy .main>svg.chart{width:1504px;height:500px;flex:none}
.frame .two.az,.frame .two.um{width:1504px;height:500px;grid-template-columns:766px 694px;flex:none}
.frame .two.az>.fig,.frame .two.um>.fig{width:766px;height:500px;display:block}
.frame .two.az>.fig>svg.chart,.frame .two.um>.fig>svg.chart{width:766px;height:500px;display:block;flex:none}
#venice .two.um>.fig>svg.chart{height:450px}
#founders .main{display:block}#founders .fgrid{height:400px;grid-template-rows:90px 90px 73px 73px 74px}#founders .fband{height:60px;margin-top:16px}
.frame .mark{display:block!important;background-position:center;background-size:contain}
.frame .quot cite,.frame .exsw>span,.frame .ffhead>span,.frame .ffbar>b{font-size:17px!important}
`;d.head.append(style);fs.writeFileSync(p,'<!doctype html>\n'+d.documentElement.outerHTML);
