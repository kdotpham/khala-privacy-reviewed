# Reviewed Khala privacy site

The reviewed copy retains 23 slides in the original order and the navy/slate palette. The original live site and repository are unchanged.

`slides/*.html` are the editable slide documents. Use `tools/rebuild-exports.cjs` and then `tools/package-downloads.py` after direct slide edits. `index.html` is the article shell. `deck/index.html` is the deck view.

The review shortens action titles, preserves material measurement qualifiers, labels adoption measures distinctly, replaces the placeholder monthly history with the supplied 350K snapshot, and restores continuous slide numbering. The appendix and visible source-note captions remain removed.

SVG exports contain the complete HTML composition in foreignObject. Standalone HTML downloads are included for consumers without foreignObject support. The HTML website is authoritative. No replacement PDF is included.

The GitHub edition has a self-contained root HTML build for easy publishing. The audit is supplied separately as HTML and CSV.
