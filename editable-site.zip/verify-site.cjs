const fs=require('fs'),path=require('path'),assert=require('assert');
let JSDOM;try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom'))}
const root=__dirname,dist=path.join(root,'dist');
const src=new JSDOM(fs.readFileSync(path.join(root,'source/index.html'),'utf8')).window.document;
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'slides.json'),'utf8'));
assert.equal(manifest.length,20);
const main=new JSDOM(fs.readFileSync(path.join(dist,'index.html'),'utf8')).window.document;
assert.deepEqual([...main.querySelectorAll('.k-author span')].map(x=>x.textContent),['0xSammy','Jack Ai-Leung']);
assert.deepEqual([...main.querySelectorAll('.r-h2 .k-label')].map(x=>x.textContent),['1','2','3','4','5','6']);
assert(!main.querySelector('#appendix,#sources,#appx'));
assert.equal(main.querySelectorAll('.privacy-slide').length,20);
function withoutNotes(d){let s=d.cloneNode(true);s.querySelectorAll('.cap,.jk-fn,.srcs').forEach(x=>x.remove());return s}
function structure(s){return [...s.querySelectorAll('*')].map(x=>({tag:x.tagName,cls:x.className.baseVal===undefined?x.className:x.className.baseVal})).filter(x=>x.tag!=='A'&&x.tag!=='SPAN')}
let checked=0,charts=0;
for(const e of manifest){
 let file=path.join(dist,e.frame);assert(fs.existsSync(file));
 let doc=new JSDOM(fs.readFileSync(file,'utf8')).window.document;
 let orig=withoutNotes(src.getElementById(e.id)),out=doc.querySelector('section.frame');
 assert.equal(out.className,orig.className);
 assert.equal(out.textContent.replace(/\s+/g,' ').trim(),orig.textContent.replace(/\s+/g,' ').trim(),'Text mismatch '+e.id);
 assert.deepEqual(structure(out),structure(orig),'Layout structure mismatch '+e.id);
 // SVG positions and dimensions must remain exactly as supplied.
 let before=[...orig.querySelectorAll('svg.chart *')],after=[...out.querySelectorAll('svg.chart *')];assert.equal(before.length,after.length);
 for(let i=0;i<before.length;i++)for(let a of ['x','y','x1','y1','x2','y2','cx','cy','r','width','height','d','transform','viewBox','text-anchor'])assert.equal(after[i].getAttribute(a),before[i].getAttribute(a),e.id+' '+a);
 for(const p of [e.html,e.svg])assert(fs.statSync(path.join(dist,p)).size>1000);
 assert(fs.readFileSync(path.join(dist,e.svg),'utf8').includes('data:font/woff2'));
 assert(!out.querySelector('.cap,.jk-fn,.srcs'));
 charts+=out.querySelectorAll('svg.chart').length;checked++;
}
let errors=[];
function checkLinks(file){let d=new JSDOM(fs.readFileSync(file,'utf8')).window.document;for(const a of d.querySelectorAll('[src],link[href],a[href]')){
 let raw=a.getAttribute('src')||a.getAttribute('href');if(!raw||/^(https?:|data:|mailto:|tel:)/.test(raw))continue;
 if(raw.startsWith('#')){if(!d.getElementById(raw.slice(1)))errors.push(file+' missing fragment '+raw);continue}
 let target=path.resolve(path.dirname(file),raw.split('#')[0].split('?')[0]);if(fs.existsSync(target)&&fs.statSync(target).isDirectory())target=path.join(target,'index.html');if(!fs.existsSync(target))errors.push(file+' missing '+raw)
}}
checkLinks(path.join(dist,'index.html'));checkLinks(path.join(dist,'deck/index.html'));
assert.deepEqual(errors,[]);
{const dd=new JSDOM(fs.readFileSync(path.join(dist,'index.html'),'utf8')).window.document;for(const f of dd.querySelectorAll('.r-body .privacy-slide')){assert.equal(f.querySelectorAll('.ix-export').length,1,'export '+f.id);assert(!f.querySelector('figcaption'),'caption '+f.id)}}
console.log(JSON.stringify({passed:true,slides:checked,charts,exportGeometry:'matches editable source',byline:'matched',downloads:'resolved',exportButtons:'one per slide',visualBrowserQA:'unavailable'}));
