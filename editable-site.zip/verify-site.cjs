const fs=require('fs'),path=require('path'),assert=require('assert');
let JSDOM;try{({JSDOM}=require('jsdom'))}catch{({JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom'))}
const root=__dirname,dist=path.join(root,'dist');
const src=new JSDOM(fs.readFileSync(path.join(root,'source/index.html'),'utf8')).window.document;
const manifest=JSON.parse(fs.readFileSync(path.join(dist,'slides.json'),'utf8'));
assert.equal(manifest.length,23);
const main=new JSDOM(fs.readFileSync(path.join(dist,'index.html'),'utf8')).window.document;
assert.deepEqual([...main.querySelectorAll('.k-author span')].map(x=>x.textContent),['0xSammy','Jack Ai-Leung']);
assert.deepEqual([...main.querySelectorAll('.r-h2 .k-label')].map(x=>x.textContent),['1','2','3']);
assert(!main.querySelector('#appendix,#sources,#appx'));
assert.equal(main.querySelectorAll('.privacy-slide').length,23);
function withoutNotes(d){let s=d.cloneNode(true);s.querySelectorAll('.cap,.jk-fn,.srcs').forEach(x=>x.remove());return s}
function structure(s){return [...s.querySelectorAll('*')].map(x=>({tag:x.tagName,cls:x.className.baseVal===undefined?x.className:x.className.baseVal})).filter(x=>x.tag!=='A'&&x.tag!=='SPAN')}
let checked=0,charts=0;
for(const e of manifest){
 let file=path.join(dist,e.frame);assert(fs.existsSync(file));
 let doc=new JSDOM(fs.readFileSync(file,'utf8')).window.document;
 let orig=withoutNotes(src.getElementById(e.id)),out=doc.querySelector('section.frame');
 assert.equal(out.className,orig.className);
 assert.equal(out.textContent.replace(/\s+/g,' ').trim(),orig.textContent.replace(/\s+/g,' ').trim(),'Text mismatch '+e.id);
 assert.deepEqual(structure(out),structure(orig),'Layout structure mismatch '+e.id);
 // SVG positions and dimensions must remain exactly as supplied.
 let before=[...orig.querySelectorAll('svg.chart *')],after=[...out.querySelectorAll('svg.chart *')];assert.equal(before.length,after.length);
 for(let i=0;i<before.length;i++)for(let a of ['x','y','x1','y1','x2','y2','cx','cy','r','width','height','d','transform','viewBox','text-anchor'])assert.equal(after[i].getAttribute(a),before[i].getAttribute(a),e.id+' '+a);
 for(const p of [e.html,e.svg])assert(fs.statSync(path.join(dist,p)).size>1000);
 assert(fs.readFileSync(path.join(dist,e.svg),'utf8').includes('data:font/woff2'));
 assert(!out.querySelector('.cap,.jk-fn,.srcs'));
 charts+=out.querySelectorAll('svg.chart').length;checked++;
}
let errors=[];
function checkLinks(file){let d=new JSDOM(fs.readFileSync(file,'utf8')).window.document;for(const a of d.querySelectorAll('[src],link[href],a[href]')){
 let raw=a.getAttribute('src')||a.getAttribute('href');if(!raw||/^(https?:|data:|mailto:|tel:)/.test(raw))continue;
 if(raw.startsWith('#')){if(!d.getElementById(raw.slice(1)))errors.push(file+' missing fragment '+raw);continue}
 let target=path.resolve(path.dirname(file),raw.split('#')[0].split('?')[0]);if(fs.existsSync(target)&&fs.statSync(target).isDirectory())target=path.join(target,'index.html');if(!fs.existsSync(target))errors.push(file+' missing '+raw)
}}
checkLinks(path.join(dist,'index.html'));checkLinks(path.join(dist,'deck/index.html'));
assert.deepEqual(errors,[]);
const js=fs.readFileSync(path.join(dist,'assets/privacy.js'),'utf8');
for(const width of [1440,390]){
 const dom=new JSDOM(fs.readFileSync(path.join(dist,'index.html'),'utf8'),{url:'https://example.test/',runScripts:'outside-only'}),w=dom.window;
 Object.defineProperty(w.HTMLElement.prototype,'clientWidth',{get(){return this.classList.contains('privacy-slide-viewport')?width:0}});
 w.eval(js);w.document.dispatchEvent(new w.Event('DOMContentLoaded'));const a=w.document.querySelector('[data-expand-slide="tokens"]');a.dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true}));
 const modal=w.document.getElementById('privacy-slide-dialog');assert(modal.hasAttribute('open'));
 assert(modal.querySelector('[data-expanded-svg]').href.endsWith('/downloads/svg/tokens.svg'));
 assert(modal.querySelector('[data-expanded-html]').href.endsWith('/downloads/html/tokens.html'));
 assert(modal.querySelector('[data-expanded-html]').hasAttribute('download'));
 assert.equal(modal.querySelector('iframe').width,'1600');
 assert(modal.querySelector('iframe').style.transform.includes(String(width/1600)));
 modal.querySelector('[data-close-slide]').click();assert(!modal.hasAttribute('open'));
}
console.log(JSON.stringify({passed:true,slides:checked,charts,exportGeometry:'matches editable source',byline:'matched',downloads:'resolved',dialog:'desktop + mobile DOM',visualBrowserQA:'unavailable'}));
