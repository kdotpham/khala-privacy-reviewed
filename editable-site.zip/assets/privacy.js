(function(){
 'use strict';
 function scale(view){var frame=view.querySelector('iframe');if(!frame)return;var width=view.clientWidth||1600,factor=width/1600;frame.style.transform='scale('+factor+')';view.style.height=(720*factor)+'px'}
 document.querySelectorAll('.privacy-slide-viewport').forEach(function(v){scale(v);if(typeof ResizeObserver==='function')new ResizeObserver(function(){scale(v)}).observe(v)});
 window.addEventListener('resize',function(){document.querySelectorAll('.privacy-slide-viewport').forEach(scale)});
 window.addEventListener('message',function(e){if(e.origin!==location.origin||!e.data||e.data.type!=='khala-anchor')return;var target=document.getElementById(e.data.id);if(target)target.scrollIntoView({behavior:'smooth',block:'start'})});
 var dialog=document.getElementById('privacy-slide-dialog'),lastFocus;
 if(!dialog){dialog=document.createElement('dialog');dialog.id='privacy-slide-dialog';dialog.className='privacy-slide-dialog';dialog.setAttribute('aria-label','Expanded research slide');dialog.innerHTML='<div class="privacy-dialog-bar"><span data-expanded-title>Khala Research</span><div><a data-expanded-svg download>Download SVG ↓</a><a data-expanded-html download>Download expanded HTML ↓</a><button data-close-slide type="button">Close ×</button></div></div><div class="privacy-expanded-scroll"><div class="privacy-slide-viewport privacy-expanded-viewport"></div></div>';document.body.append(dialog)}
 document.querySelectorAll('[data-expand-slide]').forEach(function(a){a.addEventListener('click',function(e){
  e.preventDefault();lastFocus=a;var figure=a.closest('.privacy-slide'),svg=figure.querySelector('[download]'),view=dialog.querySelector('.privacy-expanded-viewport');
  dialog.querySelector('[data-expanded-title]').textContent=figure.querySelector('.privacy-slide-title').textContent;
  var svgLink=dialog.querySelector('[data-expanded-svg]');svgLink.href=svg.href;svgLink.download=svg.download;
  var htmlLink=dialog.querySelector('[data-expanded-html]');htmlLink.href=a.href;htmlLink.download='khala-'+a.dataset.expandSlide+'.html';
  view.innerHTML='';var iframe=document.createElement('iframe');iframe.src=a.href;iframe.width='1600';iframe.height='720';iframe.title=dialog.querySelector('[data-expanded-title]').textContent;iframe.scrolling='no';view.append(iframe);
  if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');scale(view);
 })});
 function close(){if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');dialog.querySelector('.privacy-expanded-viewport').innerHTML='';if(lastFocus)lastFocus.focus()}
 dialog.querySelector('[data-close-slide]').addEventListener('click',close);
 dialog.addEventListener('click',function(e){if(e.target===dialog)close()});dialog.addEventListener('close',function(){if(lastFocus)lastFocus.focus()});
})();
