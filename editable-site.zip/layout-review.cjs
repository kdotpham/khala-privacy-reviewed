const fs=require('fs'),{JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom');let p=__dirname+'/source/index.html',dom=new JSDOM(fs.readFileSync(p,'utf8')),d=dom.window.document;
const css=d.createElement('style');css.textContent=`
/* Fixed slide geometry makes HTML and vector exports agree. */
.frame.L-top{display:block}.frame.L-top>header{position:absolute;left:48px;right:48px;top:40px;height:100px;display:block}
.frame.L-top>header h2{margin:0}.frame.L-top>header .eyebrow{margin:0 0 10px}.frame.L-top>header .dek{margin:12px 0 0}
.frame.L-top>.body{position:absolute;left:48px;right:48px;top:158px;bottom:60px;padding:0;display:flex;gap:40px}
.frame.L-left,.frame.L-right{display:block}.frame.L-left>header{position:absolute;left:48px;top:40px;bottom:60px;width:410px;display:flex;flex-direction:column;gap:18px}
.frame.L-left>.body{position:absolute;left:510px;right:48px;top:40px;bottom:60px;padding:0;display:block}
.frame.L-left>.body>.main{width:100%;height:100%;display:flex;flex-direction:column}
.frame.act{display:block}.frame.act>.actl{position:absolute;left:64px;top:190px;width:850px}.frame.act>.actr{position:absolute;right:64px;top:190px;width:520px;height:auto}
.frame .mark{position:absolute!important;width:113px!important;height:30px!important;left:auto!important;right:98px!important;bottom:24px!important;top:auto!important}
.frame .pageno{position:absolute!important;left:auto!important;right:48px!important;top:auto!important;bottom:28px!important}
.frame .review-date{position:absolute!important;left:48px!important;top:auto!important;bottom:27px!important}
.frame .main{min-width:0;min-height:0;height:100%}.frame .main>svg.chart{width:100%;height:100%;flex:none}
.frame .two{height:100%;width:100%}.frame .two>div{height:100%}.frame .two .fig>svg.chart{flex:1;width:100%;height:100%;min-height:0}
.frame .two.az,.frame .two.um{height:100%}.frame .two.az>.fig,.frame .two.um>.fig{height:100%}
.frame .two .facts{height:100%;display:grid;grid-template-rows:repeat(4,1fr)}
.frame .fact span,.frame .bp span{font-size:17px;line-height:1.35}.frame .fact{padding:10px 0}
.frame.summary>.body{top:154px;bottom:60px}.frame .exs{display:grid;height:430px;grid-template-rows:repeat(4,107.5px);flex:none}.frame .exsr{padding:15px 0;min-height:0}.frame .exsw{margin-top:12px;height:48px}
.frame .ut{display:grid;grid-template-rows:40px repeat(5,92px);height:500px;flex:none}.frame .urow{min-height:0;align-items:start}
.frame .fgrid{grid-template-rows:100px 100px 80px 80px 80px;height:440px}.frame .fgrid .pra{font-size:17px;line-height:1.3}.frame .fgrid .pq{padding:10px 0;height:auto}.frame .fgrid .pq cite{font-size:17px}.frame .fgrid .prole,.frame .fgrid .porg{font-size:17px}
.frame .fband{margin-top:12px;height:48px}.frame .fband span{font-size:17px}.frame .fband b{font-size:22px}
.frame .cal{display:grid;grid-template-rows:36px repeat(7,66px);height:498px;flex:none}.frame .crow{min-height:0;padding:10px 0}.frame .crow.chead{font-size:17px}
#pipeline .body>.main{width:1134px;flex:none}#pipeline .rail{width:330px;flex:none}#pipeline .pipe{display:grid;grid-template-rows:40px repeat(5,90px);height:490px;flex:none}.frame .pp{min-height:0;align-items:center}
#sn25 .main{display:block}#sn25 .main>svg.chart{height:370px}#sn25 .kpis{height:106px;margin-top:12px}.frame .kpis span{font-size:17px}
#edges .main>div>svg.chart{height:450px;flex:none}#edges .exq{height:35px;font-size:22px}
#bull .two .fig>svg.chart{height:450px;flex:none}#bull .two .bps{display:grid;grid-template-rows:repeat(3,1fr)}
#value .two>div>svg.chart{height:480px;flex:none}
.frame .ff{display:grid;grid-template-rows:70px repeat(3,112px);height:406px;flex:none}.frame .ffrow.part{min-height:0}.frame .ffhead{font-size:17px}.frame .ffaxis,.frame .ffaxis span,.frame .ffaxis em{font-size:17px}
.frame .ffsig{margin-top:14px;padding:12px 22px;height:68px}.frame .ffr{font-size:38px;white-space:nowrap}
.frame .actin,.frame .eyebrow,.frame .jk-net2 .jn em,.frame .fee-k,.frame .kstat,.frame .quot cite{font-size:17px}
`;
d.head.append(css);
// Use explicit SVG font attributes as well as CSS for portability.
const vars={};const rc=dom.window.getComputedStyle(d.documentElement);for(let i=0;i<rc.length;i++){const n=rc[i];if(n.startsWith('--'))vars[n]=rc.getPropertyValue(n).trim()}
const resolve=v=>{for(let i=0;i<5&&v.includes('var(');i++)v=v.replace(/var\((--[^,)]+)(?:,[^)]*)?\)/g,(_,n)=>vars[n]||'');return v.replace(/'JetBrains Mono'(?:,\s*ui-monospace)?(?:,\s*monospace)?/g,"'Host Grotesk',Arial,sans-serif")};
for(const svg of d.querySelectorAll('section.frame svg.chart')){
 const id=svg.closest('section.frame').id;let floor=['sn25','priced','operators','bull'].includes(id)?22:18;
 for(const t of svg.querySelectorAll('text,tspan')){
  const c=dom.window.getComputedStyle(t),parent=t.closest('text'),pc=dom.window.getComputedStyle(parent);let size=parseFloat(c.fontSize)||parseFloat(pc.fontSize)||18;
  const family=resolve(c.fontFamily||pc.fontFamily||"var(--sans)")||"'Host Grotesk',Arial,sans-serif";
  const fill=resolve(c.fill||pc.fill||'var(--ink)')||'#141414';
  t.style.removeProperty('font');t.style.fontFamily=family;t.style.fontSize=Math.max(floor,size)+'px';t.style.fontWeight=c.fontWeight||pc.fontWeight||'400';t.style.fontStyle='normal';t.style.fill=fill;
  t.setAttribute('font-family',family);t.setAttribute('font-size',String(Math.max(floor,size)));t.setAttribute('fill',fill);
 }
}
// Keep the snapshot number large without relying on font shorthand in SVG.
const num=d.querySelector('#mau svg text:nth-of-type(2)');num.style.fontSize='120px';num.setAttribute('font-size','120');num.setAttribute('y','240');
fs.writeFileSync(p,'<!doctype html>\n'+d.documentElement.outerHTML);
