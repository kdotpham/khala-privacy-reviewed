const fs=require('fs'),{JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom');const p=__dirname+'/source/index.html',d=new JSDOM(fs.readFileSync(p,'utf8')).window.document;
const rows=d.querySelectorAll('#tokens .jk-row');
const pay=['Senders pay fees. Issuance funds miners and development.','Users or apps pay fees. Emissions also pay operators.','Users pay fees and tips. Protocol fees reach the DAO.','Subscriptions, API credits or VVV staked for inference.','Customers pay operators. Subnet revenue is separate.'];[...rows[3].querySelectorAll('.jk-cell')].forEach((e,i)=>e.textContent=pay[i]);
rows[2].querySelectorAll('.jk-cell')[1].innerHTML='<span class="jkn"><b>100K+</b>legacy Connect wallets; current Aztec unverified</span>';
rows[2].querySelectorAll('.jk-cell')[4].innerHTML='<span class="jkn"><b>350K+</b>monthly app users; team-reported, off-chain</span>';
d.querySelector('#founders .fmid')?.remove();
d.querySelector('#sn25 .dek').textContent='Customers pay operators. Validators measure miners. The dashed operator-deposit link remains inactive while the rate is zero.';
d.querySelector('#aztec .dek').textContent='Usage remains small relative to staking and valuation. The chart compares USD amounts on a logarithmic scale. The supplied release disclosures include a critical vulnerability.';
d.querySelector('#zcash header .note').textContent='At the mid-October snapshot, ZEC’s market value is roughly twice Monero’s. Most activity still settles transparently.';
const style=d.createElement('style');style.textContent=`
.frame.jack .jk-table{display:grid;grid-template-rows:70px 135px 125px 110px 165px;height:605px;flex:none}
.frame.jack .jk-row{min-height:0}.frame .jk-net2{padding-top:12px;padding-bottom:12px}
`;d.head.append(style);fs.writeFileSync(p,'<!doctype html>\n'+d.documentElement.outerHTML);
