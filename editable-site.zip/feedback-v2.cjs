const fs=require('fs');
const {JSDOM}=require('/workspace/scratch/73056fc3ab5a/khala-html/qa/node_modules/jsdom');
const file=__dirname+'/source/index.html';
const d=new JSDOM(fs.readFileSync(file,'utf8')).window.document;
const original=new JSDOM(fs.readFileSync('/workspace/sites/khala-pricing-privacy-article/source/index.html','utf8')).window.document;
d.querySelectorAll('.review-date').forEach(e=>e.remove());
function title(id,t){const s=d.getElementById(id);s.querySelector('header h2').textContent=t;s.setAttribute('aria-label',t);s.dataset.title=t;}
title('bull','SN25 would be worth 10× at Helium’s market cap and 58× at Grass’s');
title('value','Operator deposits could turn UR usage into lasting SN25 demand');
d.querySelector('#value .dek').textContent='TAO inflows and sector interest support SN25 today. Priced operator deposits would add demand by locking UR against network traffic.';
d.querySelector('#tokens .jk-net2.ur .jn em').textContent='New';
const mau=d.getElementById('mau');
title('mau','UR reports 350K monthly users');
mau.querySelector('.dek').textContent='URnetwork’s monthly user growth, shown here with placeholder data pending the verified series.';
mau.querySelector('svg.chart').replaceWith(original.querySelector('#mau svg.chart').cloneNode(true));
mau.querySelector('svg.chart').setAttribute('aria-label','Placeholder monthly active users chart. Sample data, not for posting.');
for(const e of mau.querySelectorAll('[data-tip]')){const a=e.dataset.tip.split('||');a[2]='SAMPLE DATA — NOT FOR POSTING. Placeholder monthly series.';e.dataset.tip=a.join('||');}
const stamp=d.createElement('div');stamp.className='sample-stamp';stamp.textContent='SAMPLE DATA · NOT FOR POSTING';mau.querySelector('.main').append(stamp);
mau.querySelectorAll('header .note')[2].textContent='The bars illustrate the intended chart layout. Replace the sample monthly values before publication.';
// Wrap the longest box label rather than squeezing or clipping it.
const emissions=[...d.querySelectorAll('#sn25 svg.chart text')].find(e=>e.textContent.includes('Miners 41%'));
emissions.innerHTML='<tspan x="565" y="290">Miners 41% · validators 41%</tspan><tspan x="565" y="309">Owner 18%</tspan>';
for(const e of d.querySelectorAll('#sn25 svg.chart text.sd,#sn25 svg.chart text.capacc')){e.style.fontSize='18px';e.setAttribute('font-size','18');}
const style=d.createElement('style');style.id='feedback-v2-layout';style.textContent=fs.readFileSync(__dirname+'/feedback-v2.css','utf8');d.getElementById('feedback-v2-layout')?.remove();d.head.append(style);
fs.writeFileSync(file,'<!doctype html>\n'+d.documentElement.outerHTML);
