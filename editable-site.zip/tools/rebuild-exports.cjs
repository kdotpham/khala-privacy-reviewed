// After editing slides/*.html, run from the site root:
// npm install --no-save jsdom && node tools/rebuild-exports.cjs
const fs=require('fs'),path=require('path'),{JSDOM}=require('jsdom');
const root=path.resolve(__dirname,'..'),slides=JSON.parse(fs.readFileSync(path.join(root,'slides.json'),'utf8'));
for(const s of slides){
 const html=fs.readFileSync(path.join(root,s.frame),'utf8'),dom=new JSDOM(html),d=dom.window.document;
 const frame=d.querySelector('section.frame'),style=d.querySelector('style').textContent;
 fs.writeFileSync(path.join(root,s.html),html);
 const title=s.title.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const body=new dom.window.XMLSerializer().serializeToString(frame);
 fs.writeFileSync(path.join(root,s.svg),`<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="1600" height="720" viewBox="0 0 1600 720" role="img" aria-label="${title}"><title>${title}</title><foreignObject x="0" y="0" width="1600" height="720"><div xmlns="http://www.w3.org/1999/xhtml"><style><![CDATA[${style}\n.frame{font-family:var(--sans);color:var(--ink);line-height:normal}]]></style>${body}</div></foreignObject></svg>`);
}
console.log(`Updated HTML and SVG exports for ${slides.length} slides. Rebuild the downloads ZIP next.`);
