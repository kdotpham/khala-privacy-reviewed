from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
with ZipFile(root/'downloads/khala-slides.zip','w',ZIP_DEFLATED) as z:
 for folder in ['html','svg']:
  for p in sorted((root/'downloads'/folder).glob('*')):z.write(p,p.relative_to(root/'downloads'))
print('Updated downloads/khala-slides.zip')
