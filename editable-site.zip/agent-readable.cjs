// Derive all reader/agent formats from the same slide DOM used for exports.
const fs=require('fs'),path=require('path');
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const compact=s=>String(s||'').replace(/\s+/g,' ').trim();
function words(node){
 if(node.nodeType===3)return node.textContent;
 if(node.nodeType!==1)return '';
 if(node.matches('script,style,.mark,.pageno,.cap,.jk-fn,.srcs'))return '';
 if(node.tagName==='BR')return '\n';
 const value=[...node.childNodes].map(words).join(' ');
 return /^(P|DIV|LI|H[1-6]|HEADER|SECTION|FOOTER|BLOCKQUOTE|SVG|TEXT)$/.test(node.tagName)?'\n'+value+'\n':value;
}
function extract(slide,number,meta){
 const clone=slide.cloneNode(true);
 clone.querySelectorAll('script,style,.mark,.pageno,.slide-footer,.cap,.jk-fn,.srcs').forEach(e=>e.remove());
 const charts=[...clone.querySelectorAll('svg[role="img"]')].map(svg=>({
  description:svg.getAttribute('aria-label')||'Chart',
  labels:[...svg.querySelectorAll('text')].map(t=>compact(words(t))).filter(Boolean),
  details:[...svg.querySelectorAll('[data-tip]')].map(t=>{const [label,description='',source='']=t.dataset.tip.split('||');return {label,description,source}})
 }));
 const hoverDetails=[...clone.querySelectorAll('[data-tip]')].map(t=>{const [label,description='',source='']=t.dataset.tip.split('||');return {label,description,source}});
 const tableSelectors=['.jk-table','.ut','.pipe','.ff','.cal'];
 const tables=tableSelectors.flatMap(sel=>[...clone.querySelectorAll(sel)].map(t=>({rows:[...t.children].filter(r=>r.matches('.jk-row,.urow,.pp,.ffrow,.crow')).map(r=>[...r.children].map(c=>compact(words(c))))}))).filter(t=>t.rows.length>1);
 const body=clone.cloneNode(true);body.querySelectorAll('svg,'+tableSelectors.join(',')).forEach(e=>e.remove());
 const paragraphs=words(body).split('\n').map(compact).filter(Boolean);
 const title=compact(slide.querySelector('header h2,.actl h2,.jk-intro h1')?.textContent)||slide.dataset.title;
 const warnings=[];
 if(slide.id==='mau')warnings.push('SAMPLE DATA · NOT FOR POSTING. Monthly chart values are placeholders, not observed history. The 350K headline is separately team-reported.');
 if(slide.id==='edges')warnings.push('Primary paper checked on 2026-10-18: address-to-IP linking under controlled router observations; Ethereum mainnet and testnet are separate. Not a population-wide exposure estimate; UR (SN25) was not tested.');
 if(slide.id==='sn25')warnings.push('Design is distinct from launch: the documented launch has a UR-run operator and sole validator. The 200-fleet figure is a design cap.');
 if(slide.id==='watch')warnings.push('End-2027 scenario ranges are illustrative assumptions, not forecasts or a supplied valuation model.');
 return {slide_number:number,id:slide.id,title,url:meta.origin+'/#'+slide.id,kind:slide.classList.contains('act')?'section_divider':'content',data_status:slide.id==='mau'?'sample_not_for_publication':slide.id==='watch'?'illustrative_scenarios':'supplied_research',warnings,paragraphs,text:paragraphs.join('\n'),charts,tables,hover_details:hoverDetails};
}
function slideHTML(s){
 const rows=s.hover_details.map(v=>`<tr><th scope="row">${esc(v.label)}</th><td>${esc(v.description)}</td><td>${esc(v.source)}</td></tr>`).join('');
 return `<section id="text-${s.id}" aria-labelledby="text-title-${s.id}"><h2 id="text-title-${s.id}">${s.slide_number}. ${esc(s.title)}</h2>${s.warnings.map(w=>`<p class="data-warning"><strong>${esc(w)}</strong></p>`).join('')}${s.paragraphs.filter(p=>p!==s.title).map(p=>`<p>${esc(p)}</p>`).join('')}${s.tables.map(t=>`<div class="text-table-wrap"><table><caption>Slide table, in reading order</caption><tbody>${t.rows.map((r,i)=>'<tr>'+r.map(c=>i===0?`<th scope="col">${esc(c)}</th>`:`<td>${esc(c)}</td>`).join('')+'</tr>').join('')}</tbody></table></div>`).join('')}${s.charts.map(c=>`<h3>${esc(c.description)}</h3><p>Chart labels in display order: ${c.labels.map(esc).join(' · ')}</p>`).join('')}${rows?`<div class="text-table-wrap"><table><caption>Chart details and interactive notes</caption><thead><tr><th scope="col">Metric or element</th><th scope="col">Detail</th><th scope="col">Source supplied with the slide</th></tr></thead><tbody>${rows}</tbody></table></div>`:''}<p><a href="${esc(s.url)}">View slide ${s.slide_number}</a></p></section>`;
}
module.exports=function({document:d,slides,meta,dist}){
 const records=slides.map((s,i)=>extract(s,i+1,meta));
 const report={schema_version:'1.0',title:meta.title,url:meta.origin+'/',language:'en',publication_date:meta.releaseDate,reading_minutes:meta.readingMinutes,authors:[{name:'0xSammy',url:'https://x.com/0xSammy'},{name:'Jack Ai-Leung',url:'https://x.com/haitzu'}],market_data_as_of:'2026-10-15',research_status:'Targeted primary-source audit on 2026-10-18 checked slide 15 and UR (SN25) mechanism wording. Other market, adoption and milestone figures remain supplied research, not independently re-verified.',sample_data_slide_numbers:[16],network_privacy_chart_scope:['Nym','UR (SN25)'],slide_count:records.length,slides:records};
 fs.writeFileSync(path.join(dist,'report.json'),JSON.stringify(report,null,2)+'\n');
 const pipe=s=>s.replace(/\|/g,'\\|').replace(/\n/g,' ');
 const md=['# '+meta.title,'','Authors: 0xSammy; Jack Ai-Leung','Publication date: '+meta.releaseDate,'Market-cap snapshot: 2026-10-15','Canonical report: '+meta.origin+'/','','Slide 16: SAMPLE DATA · NOT FOR POSTING. Its monthly chart contains placeholders. Slide 22 scenarios are illustrative assumptions.','',...records.flatMap(s=>['## Slide '+s.slide_number+': '+s.title,'',...s.warnings.map(w=>'**'+w+'**'),'',...s.paragraphs.filter(p=>p!==s.title),'',...s.tables.flatMap(t=>[...t.rows.map((r,i)=>'| '+r.map(pipe).join(' | ')+' |'+(i===0?'\n| '+r.map(()=>'---').join(' | ')+' |':'')), '']),...s.charts.flatMap(c=>['### '+c.description,'','Chart labels in display order: '+c.labels.join(' · '),'']),...(s.hover_details.length?['### Chart details and interactive notes','','| Metric or element | Detail | Source supplied with the slide |','| --- | --- | --- |',...s.hover_details.map(v=>'| '+[v.label,v.description,v.source].map(pipe).join(' | ')+' |'),'']:[]),'[View slide '+s.slide_number+']('+s.url+')',''])].join('\n');
 fs.writeFileSync(path.join(dist,'report.md'),md+'\n');
 const transcript=records.map(slideHTML).join('\n');
 const plainCSS=':root{color-scheme:light dark}body{max-width:960px;margin:0 auto;padding:32px 24px;font:18px/1.65 system-ui,sans-serif}a{color:inherit;text-underline-offset:3px}h1{font-size:2.4rem;line-height:1.1}h2{font-size:1.6rem;line-height:1.25;margin-top:3rem}h3{font-size:1.1rem}table{border-collapse:collapse;font-size:.9rem;width:100%}td,th{text-align:left;vertical-align:top;padding:10px;border-bottom:1px solid #8888}caption{text-align:left;font-weight:600;padding:12px 0}.text-table-wrap{overflow:auto}.data-warning{border-left:4px solid currentColor;padding-left:16px}nav{display:flex;gap:24px;flex-wrap:wrap}';
 fs.writeFileSync(path.join(dist,'report.html'),`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(meta.title)} · Text version</title><link rel="canonical" href="${esc(meta.origin)}/"><link rel="alternate" type="text/markdown" href="report.md"><link rel="alternate" type="application/json" href="report.json"><style>${plainCSS}</style></head><body><header><nav aria-label="Report formats"><a href="./">← Visual report</a><a href="report.md" download>Markdown ↓</a><a href="report.json" download>Structured JSON ↓</a></nav><h1>${esc(meta.title)}</h1><p>0xSammy · Jack Ai-Leung</p><p>Publication: <time datetime="${meta.releaseDate}">November 2, 2026</time> · Privacy · ${meta.readingMinutes} min read</p><p>Market-cap snapshot: 15 October 2026. ${esc(report.research_status)}</p><p class="data-warning"><strong>Slide 16 contains sample monthly data, not for posting. Slide 22 contains illustrative scenarios.</strong></p></header><main>${transcript}</main></body></html>`);
 fs.writeFileSync(path.join(dist,'llms.txt'),`# ${meta.title}\n\n> Khala Research report by 0xSammy and Jack Ai-Leung. ${records.length} slides. Publication date: ${meta.releaseDate}. Market-cap snapshot: 2026-10-15.\n\n## Report formats\n\n- [Full report in Markdown](${meta.origin}/report.md): Slide text, chart labels, tables, interactive details and supplied source attributions.\n- [Structured report JSON](${meta.origin}/report.json): Stable slide IDs, titles, data status, chart labels, tables and hover notes.\n- [Readable HTML](${meta.origin}/report.html): Complete report without JavaScript or iframe dependencies.\n- [Visual report](${meta.origin}/): Interactive slide compositions.\n\n## Data qualifications\n\n- Slide 16 monthly chart values are SAMPLE DATA, NOT FOR POSTING, and must not be treated as observed history.\n- Slide 22 scenario ranges are illustrative assumptions.\n- Slide 15 was checked against the primary paper and UR (SN25) mechanism copy against official documentation on 2026-10-18. Other supplied metrics and dates remain unverified.\n- The network-privacy comparison on slide 7 covers Nym and UR (SN25) only.\n`);
 d.querySelectorAll('link[rel="alternate"][type="text/plain"]').forEach(l=>l.remove());
 for(const [type,href] of [['text/plain','llms.txt'],['text/html','report.html'],['text/markdown','report.md'],['application/json','report.json']]){const l=d.createElement('link');l.rel='alternate';l.type=type;l.href=href;d.head.append(l)}
 const schema={'@context':'https://schema.org','@type':'Article','@id':meta.origin+'/#report',headline:meta.title,url:meta.origin+'/',datePublished:meta.releaseDate,inLanguage:'en',author:report.authors.map(a=>({'@type':'Person',name:a.name,url:a.url})),publisher:{'@type':'Organization',name:'Khala Research',url:'https://www.khala.io/'},articleBody:records.map(s=>s.slide_number+'. '+s.title+'\n'+s.text+'\n'+s.tables.map(t=>t.rows.map(r=>r.join(' | ')).join('\n')).join('\n')+'\n'+s.charts.map(c=>c.description+': '+c.labels.join(' · ')).join('\n')+'\n'+s.hover_details.map(v=>[v.label,v.description,v.source].filter(Boolean).join(' — ')).join('\n')).join('\n\n'),encoding:[{'@type':'MediaObject',contentUrl:meta.origin+'/report.md',encodingFormat:'text/markdown'},{'@type':'MediaObject',contentUrl:meta.origin+'/report.json',encodingFormat:'application/json'}]};
 const script=d.createElement('script');script.type='application/ld+json';script.textContent=JSON.stringify(schema).replace(/</g,'\\u003c');d.head.append(script);
 const link=d.createElement('a');link.className='privacy-deck-link';link.href='report.html';link.textContent='Text version ↗';d.querySelector('.privacy-downloads').append(link);
 const details=d.createElement('details');details.className='privacy-report-text';details.innerHTML='<summary>Read the full report as text</summary><p><a href="report.md" download>Download Markdown ↓</a> · <a href="report.json" download>Download structured JSON ↓</a></p>'+transcript;d.querySelector('.r-body').append(details);
 return report;
};
