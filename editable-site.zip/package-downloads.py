from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).parent
out=root/'dist/downloads/khala-slides.zip'
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for folder in ['html','svg']:
  for p in sorted((root/'dist/downloads'/folder).glob('*')):z.write(p,p.relative_to(root/'dist/downloads'))
print('Packaged slide downloads:',out.stat().st_size)
