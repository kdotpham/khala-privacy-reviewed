/* Khala site behaviour: theme, viewport scale, nav, motion helpers and the research list. */
(function () {
  'use strict';



  /** Above a 1920px-wide viewport, scale the whole page as one composition (also keeps the
      layout filling the screen when the reader zooms out). The head script applies it pre-paint. */
  function initViewportScale() {
    var root = document.documentElement;
    var apply = function () {
      var z = Math.max(1, window.innerWidth / 1920);
      root.style.zoom = z > 1 ? z : '';
      if (z > 1) root.style.setProperty('--k-zoom', z); else root.style.removeProperty('--k-zoom');
    };
    window.addEventListener('resize', apply);
  }

  /** Publish the announcement bar and nav heights: the nav pins under the bar, the hero fills the rest. */
  function initChromeHeight() {
    var bar = document.querySelector('.k-announce');
    var nav = document.querySelector('.k-nav');
    if (!nav) return;
    var set = function () {
      // On phones the bar scrolls away (khala.css), so only a pinned bar counts toward the fixed chrome.
      var barH = bar && getComputedStyle(bar).position === 'sticky' ? bar.offsetHeight : 0;
      document.documentElement.style.setProperty('--k-announce-h', barH + 'px');
      document.documentElement.style.setProperty('--k-chrome-h', (nav.offsetHeight + barH) + 'px');
    };
    set();
    window.addEventListener('resize', set);
    // Web fonts change the bar height once they load; measure again then.
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(set);
  }

  /** Label the announcement bar with the report's age ("New 8 days ago") from its data-date (YYYY-MM-DD).
      Without JS, or with a bad date, the static "New report" label stays. */
  function initAnnounceAge() {
    var label = document.querySelector('.k-announce .k-label[data-date]');
    if (!label) return;
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(label.getAttribute('data-date'));
    if (!m) return;
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var days = Math.round((today - new Date(+m[1], +m[2] - 1, +m[3])) / 86400000);
    if (days < 0) return;
    // "New" drops on phones (k-hide-sm) so the bar stays on one line, as "New report" did.
    var age = days === 0 ? 'today' : days + (days === 1 ? ' day' : ' days') + ' ago';
    label.textContent = '';
    var lead = document.createElement('span');
    lead.className = 'k-hide-sm';
    lead.textContent = 'New ';
    label.appendChild(lead);
    label.appendChild(document.createTextNode(age));
  }

  /** Scroll reveal: components fade and rise into place as they enter the viewport, staggered within
      a group. Body paragraphs are left alone so reading is never interrupted. Content stays visible
      without JS, without IntersectionObserver, with reduced motion, and in print. */
  var REVEAL_GROUPS = [
    '.k-hero-grid > *', '.k-page-head .k-wrap > *', '.k-section .k-head', '.k-feature', '.k-grid-3 > *',
    '.k-readers-grid > li', '.k-manifesto-inner > *', '.k-cover-grid > *', '.k-eps > *', '.k-tt-wrap',
    '.k-list > .k-row:not(.k-row--head)', '.k-more', '.k-drafts > .k-group-label', '.k-subscribe > div',
    '.r-hero-grid > div:first-child > *', '.r-cover', '.r-body .r-h2', '.r-body .r-h3', '.r-figure', '.r-takeaways',
    '.r-table-wrap', '.ix-panel', '.d-head > *', '.d-viewer'
  ];

  function initScrollReveal() {
    if (!('IntersectionObserver' in window)) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var io = new IntersectionObserver(function (entries) {
      var batch = entries.filter(function (e) { return e.isIntersecting; });
      batch.forEach(function (e, i) {
        // Items arriving together cascade; cap the delay so long lists never feel slow.
        e.target.style.transitionDelay = Math.min(i, 6) * 70 + 'ms';
        e.target.classList.add('is-in');
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    REVEAL_GROUPS.forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) {
        // Never nest reveals: an animated parent already carries its children.
        if (el.closest('.k-rv') || el.querySelector('.k-rv')) return;
        el.classList.add('k-rv');
        io.observe(el);
      });
    });
    // Anything the reader skipped past (fast scroll, contents-link jump) shows at once instead of
    // animating in on the way back up.
    var ticking = false;
    var revealPassed = function () {
      ticking = false;
      document.querySelectorAll('.k-rv:not(.is-in)').forEach(function (el) {
        if (el.getBoundingClientRect().bottom < 0) { el.classList.add('is-in'); io.unobserve(el); }
      });
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(revealPassed); }
    }, { passive: true });
    // Clear the stagger once revealed so hover transitions are not delayed.
    document.addEventListener('transitionend', function (e) {
      if (e.target.classList && e.target.classList.contains('is-in')) e.target.style.transitionDelay = '';
    });
  }

  /** Export PNG on every report infographic: renders the graphic's panel at 2x with html-to-image (loaded on
      first click from jsDelivr, the same build the Robotics Token Landscape page uses) and downloads it. */
  var HTML_TO_IMAGE = 'https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/dist/html-to-image.js';
  var htmlToImageLoad = null;
  function loadHtmlToImage() {
    if (window.htmlToImage) return Promise.resolve(window.htmlToImage);
    if (!htmlToImageLoad) {
      htmlToImageLoad = new Promise(function (resolve, reject) {
        var s = document.createElement('script');
        s.src = HTML_TO_IMAGE;
        s.onload = function () { resolve(window.htmlToImage); };
        s.onerror = function () { htmlToImageLoad = null; reject(new Error('Could not load the export library')); };
        document.head.appendChild(s);
      });
    }
    return htmlToImageLoad;
  }

  function initFigureExport() {
    document.querySelectorAll('figure.ix').forEach(function (fig) {
      var panel = fig.querySelector('.ix-panel');
      if (!panel || fig.querySelector('.ix-export')) return;
      var tools = document.createElement('div');
      tools.className = 'ix-tools';
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'ix-export';
      btn.textContent = 'Export PNG';
      tools.appendChild(btn);
      panel.insertAdjacentElement('afterend', tools);
      btn.addEventListener('click', function () {
        var id = (fig.getAttribute('aria-labelledby') || 'graphic').replace(/^ix-|-t$/g, '');
        var theme = document.documentElement.getAttribute('data-theme') || 'light';
        var bg = getComputedStyle(document.body).backgroundColor;
        var pad = 40;
        btn.disabled = true; btn.textContent = 'Exporting…';
        loadHtmlToImage()
          .then(function () { return document.fonts.ready; })
          .then(function () {
            return window.htmlToImage.toPng(panel, {
              pixelRatio: 2, backgroundColor: bg,
              width: panel.offsetWidth + pad * 2, height: panel.offsetHeight + pad * 2,
              style: { margin: '0', padding: pad + 'px ' + pad + 'px', boxSizing: 'content-box' }
            });
          })
          .then(function (url) {
            var a = document.createElement('a');
            a.href = url; a.download = 'khala-' + id + '-' + theme + '.png';
            document.body.appendChild(a); a.click(); a.remove();
          })
          .catch(function (err) { console.error('PNG export failed', err); btn.textContent = 'Export failed'; })
          .then(function () { setTimeout(function () { btn.disabled = false; btn.textContent = 'Export PNG'; }, 1200); });
      });
    });
  }

  /** Toggle the nav border once the page has scrolled past the top. */
  function initNavScrollState() {
    var nav = document.querySelector('.k-nav');
    if (!nav) return;
    var update = function () { nav.classList.toggle('is-scrolled', window.scrollY > 8); };
    update();
    window.addEventListener('scroll', update, { passive: true });
  }

  /** Open and close the mobile menu, closing it again after a link is followed. */
  function initMobileMenu() {
    var nav = document.querySelector('.k-nav');
    var btn = document.querySelector('.k-menu-btn');
    if (!nav || !btn) return;
    var setOpen = function (open) {
      nav.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    };
    btn.addEventListener('click', function () { setOpen(!nav.classList.contains('is-open')); });
    nav.querySelectorAll('.k-nav-links a').forEach(function (a) {
      a.addEventListener('click', function () { setOpen(false); });
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
  }

  /** Flip <html data-theme> between light (default) and dark, and persist the reader's choice. */
  function initThemeToggle() {
    var root = document.documentElement;
    var meta = document.querySelector('meta[name="theme-color"]');
    var buttons = document.querySelectorAll('.k-theme-btn');
    var apply = function (theme) {
      root.setAttribute('data-theme', theme);
      if (meta) meta.setAttribute('content', theme === 'light' ? '#FFFFFF' : '#0B0E15');
      buttons.forEach(function (b) {
        b.setAttribute('aria-label', theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode');
      });
    };
    apply(root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');
    // No saved choice: follow the system setting, including changes while the page is open.
    var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
    var onSystemChange = function (e) {
      var saved = null;
      try { saved = localStorage.getItem('khala-theme'); } catch (err) { /* storage blocked: treat as no saved choice */ }
      if (saved !== 'dark' && saved !== 'light') apply(e.matches ? 'dark' : 'light');
    };
    if (mq && mq.addEventListener) mq.addEventListener('change', onSystemChange);
    buttons.forEach(function (b) {
      b.addEventListener('click', function () {
        var next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
        apply(next);
        try { localStorage.setItem('khala-theme', next); } catch (e) { /* storage blocked: theme still applies for this page view */ }
      });
    });
  }

  /** Wrap plain-text primary button labels so CSS can roll a duplicate label in on hover. */
  function initButtonRoll() {
    document.querySelectorAll('a.k-btn, button.k-btn').forEach(function (btn) {
      if (btn.children.length || !btn.textContent.trim()) return;
      var label = btn.textContent.trim();
      btn.textContent = '';
      var roll = document.createElement('span');
      roll.className = 'k-roll';
      var a = document.createElement('span');
      a.textContent = label;
      var b = document.createElement('span');
      b.textContent = label;
      b.setAttribute('aria-hidden', 'true');
      roll.append(a, b);
      btn.appendChild(roll);
    });
  }

  /** Run decorative animations only while they are on screen (saves CPU and battery). */
  function initLiveAnimations() {
    var diagrams = document.querySelectorAll('.k-shot');
    var index = document.querySelector('.k-index');
    var marquee = document.querySelector('.k-marquee');
    if (!('IntersectionObserver' in window)) {
      diagrams.forEach(function (d) { d.classList.add('is-live'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.target === index || e.target === marquee) e.target.classList.toggle('is-paused', !e.isIntersecting);
        else e.target.classList.toggle('is-live', e.isIntersecting);
      });
    }, { rootMargin: '80px' });
    diagrams.forEach(function (d) { io.observe(d); });
    if (index) io.observe(index);
    if (marquee) io.observe(marquee);
  }

  /** Research index: sortable columns (date / report / area) plus "Read more". The first five rows
      of the current order are visible until Read more is used; sorting keeps that rule. */
  function initResearchIndex() {
    // Shared by the research and podcast indexes: [data-index] lists set their own visible-row limit.
    var list = document.getElementById('report-list') || document.querySelector('[data-index]');
    if (!list) return;
    var head = list.querySelector('.k-row--head');
    var rows = Array.prototype.slice.call(list.querySelectorAll('.k-row[data-date]'));
    var more = document.querySelector('[data-read-more]');
    var LIMIT = parseInt(list.getAttribute('data-limit') || '5', 10);
    var expanded = false;
    var applyLimit = function () {
      rows.forEach(function (row, idx) { row.hidden = !expanded && idx >= LIMIT; });
      if (!more) return;
      more.hidden = rows.length <= LIMIT;
      more.setAttribute('aria-expanded', String(expanded));
      more.innerHTML = expanded ? 'Show fewer <span aria-hidden="true">&uarr;</span>'
        : 'Show all ' + rows.length + ' reports <span aria-hidden="true">&darr;</span>';
    };
    var sortBy = function (key, dir) {
      rows.sort(function (a, b) {
        var x = a.getAttribute('data-' + key).toLowerCase();
        var y = b.getAttribute('data-' + key).toLowerCase();
        var c = x < y ? -1 : x > y ? 1 : 0;
        if (c === 0 && key !== 'date') c = a.getAttribute('data-date') < b.getAttribute('data-date') ? 1 : -1;
        return dir === 'asc' ? c : -c;
      });
      rows.forEach(function (row) { list.appendChild(row); });
      applyLimit();
    };
    if (head) {
      var buttons = Array.prototype.slice.call(head.querySelectorAll('button.k-sort'));
      var menu = null;
      // Mark the active column header and sort; the phone menu and the header buttons stay in step.
      var apply = function (btn, dir) {
        buttons.forEach(function (b) {
          var on = b === btn;
          b.setAttribute('aria-pressed', String(on));
          b.setAttribute('data-dir', on ? dir : '');
          b.querySelector('span').innerHTML = on ? (dir === 'asc' ? '&uarr;' : '&darr;') : '';
          b.setAttribute('aria-label', b.textContent.trim() + (on ? (dir === 'asc' ? ', sorted ascending' : ', sorted descending') : ''));
        });
        if (menu) menu.value = btn.getAttribute('data-sort') + ':' + dir;
        sortBy(btn.getAttribute('data-sort'), dir);
      };
      buttons.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var key = btn.getAttribute('data-sort');
          var active = btn.getAttribute('aria-pressed') === 'true';
          var first = btn.getAttribute('data-first') || (key === 'date' ? 'desc' : 'asc');
          apply(btn, active ? (btn.getAttribute('data-dir') === 'asc' ? 'desc' : 'asc') : first);
        });
      });
      // Phones hide the column headers, so offer the same sorts as one compact menu above the list.
      menu = document.createElement('select');
      menu.setAttribute('aria-label', 'Sort');
      buttons.forEach(function (btn) {
        var key = btn.getAttribute('data-sort');
        var name = btn.textContent.replace(/[\u2191\u2193]/g, '').trim();
        var pairs = key === 'date' ? [['desc', 'Newest first'], ['asc', 'Oldest first']]
          : key === 'duration' ? [['desc', 'Longest first'], ['asc', 'Shortest first']]
          : key === 'views' ? [['desc', 'Most viewed'], ['asc', 'Least viewed']]
          : btn.getAttribute('data-first') === 'desc' ? [['desc', name + ': highest first'], ['asc', name + ': lowest first']]
          : [['asc', name + ': A to Z'], ['desc', name + ': Z to A']];
        pairs.forEach(function (p) {
          var o = document.createElement('option');
          o.value = key + ':' + p[0]; o.textContent = p[1];
          menu.appendChild(o);
        });
      });
      menu.addEventListener('change', function () {
        var parts = menu.value.split(':');
        apply(buttons.filter(function (b) { return b.getAttribute('data-sort') === parts[0]; })[0], parts[1]);
      });
      var wrap = document.createElement('label');
      wrap.className = 'k-sort-menu';
      wrap.innerHTML = '<span class="k-label">Sort</span>';
      wrap.appendChild(menu);
      head.parentNode.insertBefore(wrap, head);
    }
    if (more) {
      // Toggle: expand to every report, or collapse back to the latest five and return to the list top.
      more.addEventListener('click', function () {
        var firstHidden = rows.filter(function (r) { return r.hidden; })[0];
        expanded = !expanded;
        applyLimit();
        if (expanded && firstHidden) firstHidden.focus();
        if (!expanded) list.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }
    sortBy('date', 'desc');
  }

  /** Report pages: reading-progress bar and current-section highlight in the contents rail. */
  function initReportNav() {
    var bar = document.querySelector('.r-progress span');
    var body = document.querySelector('.r-body');
    if (!bar || !body) return;
    var links = {};
    document.querySelectorAll('.r-toc a[data-toc]').forEach(function (a) { links[a.getAttribute('data-toc')] = a; });
    var update = function () {
      var r = body.getBoundingClientRect();
      var total = r.height - window.innerHeight * 0.6;
      var done = Math.min(1, Math.max(0, -r.top / Math.max(total, 1)));
      bar.style.transform = 'scaleX(' + done + ')';
    };
    // One layout read per frame, not per scroll event.
    var queued = false;
    var onScroll = function () {
      if (queued) return;
      queued = true;
      requestAnimationFrame(function () { queued = false; update(); });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
    var setCurrent = initTocBar(links);
    var sections = Array.prototype.filter.call(document.querySelectorAll('.r-section[id]'), function (sec) { return links[sec.id]; });
    var active = null;
    // Current section: the last one whose top has passed under the pinned chrome (nav, plus the contents bar on
    // tablet and phone). Checked once per frame on scroll, so jumps and resizes never leave it stale.
    var markCurrent = function () {
      var rail = document.querySelector('.r-rail');
      var pinned = rail && getComputedStyle(rail).position === 'sticky' && rail.getBoundingClientRect().top < 200 ? rail.getBoundingClientRect().bottom : 0;
      var line = Math.max(pinned, parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--k-chrome-h')) || 110) + 40;
      var cur = sections[0];
      sections.forEach(function (sec) { if (sec.getBoundingClientRect().top <= line) cur = sec; });
      if (!cur || cur === active) return;
      if (active) links[active.id].removeAttribute('aria-current');
      active = cur;
      links[cur.id].setAttribute('aria-current', 'true');
      setCurrent(links[cur.id]);
    };
    var queuedMark = false;
    var onScrollMark = function () {
      if (queuedMark) return;
      queuedMark = true;
      requestAnimationFrame(function () { queuedMark = false; markCurrent(); });
    };
    window.addEventListener('scroll', onScrollMark, { passive: true });
    window.addEventListener('resize', onScrollMark);
    markCurrent();
  }

  /** Tablet and phone: the contents list collapses into a bar pinned under the nav that names the current
      section and opens the full list on tap (CSS shows it at 1080px and below). Returns the updater the
      section observer calls. */
  function initTocBar(links) {
    var toc = document.querySelector('.r-toc');
    var list = toc && toc.querySelector('ol');
    if (!toc || !list) return function () {};
    if (!list.id) list.id = 'r-toc-list';
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'r-toc-toggle';
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-controls', list.id);
    btn.innerHTML = '<span class="k-label">Contents</span><span class="r-toc-current"></span><span class="r-toc-chev" aria-hidden="true"></span>';
    toc.insertBefore(btn, toc.firstChild);
    // Also gated here, not only in CSS, so a cached older stylesheet can never show the bar on desktop.
    var mq = window.matchMedia('(max-width: 1080px)');
    var gate = function () { btn.hidden = !mq.matches; if (!mq.matches) setOpen(false); };
    var current = btn.querySelector('.r-toc-current');
    var setOpen = function (open) { toc.classList.toggle('is-open', open); btn.setAttribute('aria-expanded', String(open)); };
    btn.addEventListener('click', function () { setOpen(!toc.classList.contains('is-open')); });
    gate();
    if (mq.addEventListener) mq.addEventListener('change', gate); else if (mq.addListener) mq.addListener(gate);
    list.addEventListener('click', function (e) { if (e.target.closest('a')) setOpen(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });
    document.addEventListener('click', function (e) { if (!toc.contains(e.target)) setOpen(false); });
    var set = function (link) { current.textContent = link.textContent.replace(/^\s*\d+\s*/, '').trim(); };
    var first = list.querySelector('a');
    if (first) set(first);
    return set;
  }

  /** Lite YouTube: swap the thumbnail button for a privacy-enhanced player only when clicked. */
  function initLiteVideos() {
    document.querySelectorAll('[data-video]').forEach(function (btn) {
      // Fallback link in the caption, so the video stays reachable if the embedded player fails.
      var vid = btn.getAttribute('data-video'), t = parseInt(btn.getAttribute('data-start') || '0', 10);
      var cap = btn.closest('figure') && btn.closest('figure').querySelector('figcaption');
      if (cap && /^[A-Za-z0-9_-]{11}$/.test(vid) && !cap.querySelector('.r-video-yt')) {
        var yt = document.createElement('a');
        yt.className = 'r-video-yt'; yt.target = '_blank'; yt.rel = 'noopener noreferrer';
        yt.href = 'https://www.youtube.com/watch?v=' + vid + (t > 0 ? '&t=' + t + 's' : '');
        yt.textContent = 'Watch on YouTube';
        cap.appendChild(document.createTextNode(' '));
        cap.appendChild(yt);
      }
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-video');
        if (!/^[A-Za-z0-9_-]{11}$/.test(id)) return;
        var frame = document.createElement('iframe');
        var start = parseInt(btn.getAttribute('data-start') || '0', 10);
        // youtube.com rather than youtube-nocookie.com: the nocookie host intermittently returns 502s. YouTube also
        // refuses to play (Error 153) when the embed gets no referrer, so send the origin explicitly.
        frame.src = 'https://www.youtube.com/embed/' + id + '?autoplay=1&rel=0&playsinline=1' +
          (start > 0 ? '&start=' + start : '');
        frame.referrerPolicy = 'strict-origin-when-cross-origin';
        frame.title = btn.getAttribute('aria-label') || 'Video';
        frame.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
        frame.allowFullscreen = true;
        btn.replaceWith(frame);
        frame.focus();
      });
    });
  }

  /** Theme shots: nudge each detection score by up to 0.02 every few seconds while the card is on
      screen, so the overlay reads as a live model output. Static under reduced motion. */
  function initVisionScores() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var scores = document.querySelectorAll('.k-shot [data-score]');
    if (!scores.length) return;
    window.setInterval(function () {
      scores.forEach(function (el) {
        if (!el.closest('.k-shot').classList.contains('is-live') || Math.random() < 0.5) return;
        var base = parseFloat(el.getAttribute('data-score'));
        var next = Math.min(0.99, base + (Math.round(Math.random() * 4) - 2) / 100);
        el.textContent = next.toFixed(2);
      });
    }, 1800);
  }

  /** Report figures: click or Enter opens the chart in a full-screen viewer at the largest size that
      fits the screen (one zoom level only). Clicking the chart again zooms back out (closes), as do
      Esc, Close or a click outside it. */
  function initFigureZoom() {
    var imgs = document.querySelectorAll('.r-figure > img');
    if (!imgs.length || typeof HTMLDialogElement !== 'function') return;
    var box = document.createElement('dialog');
    box.className = 'r-zoom';
    box.innerHTML = '<button class="r-zoom-close" type="button" aria-label="Close">Close</button>' +
      '<div class="r-zoom-stage"><img alt=""></div><p class="r-zoom-cap"></p>';
    document.body.appendChild(box);
    var stage = box.querySelector('.r-zoom-stage');
    var big = stage.querySelector('img');
    var cap = box.querySelector('.r-zoom-cap');
    box.querySelector('.r-zoom-close').addEventListener('click', function () { box.close(); });
    // Any click while zoomed closes it: the image, the caption or the dark area around them.
    box.addEventListener('click', function () { box.close(); });
    imgs.forEach(function (img) {
      img.tabIndex = 0;
      img.setAttribute('role', 'button');
      img.setAttribute('aria-label', 'Enlarge figure: ' + (img.alt || 'chart'));
      var open = function () {
        big.src = img.src;  // src is the full-size file; srcset may have picked a smaller one for the column
        big.alt = img.alt;
        var fc = img.parentNode.querySelector('figcaption');
        cap.textContent = fc ? fc.textContent : '';
        box.showModal();
      };
      img.addEventListener('click', open);
      img.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
      });
    });
  }

  /** Endless CSS loops (logo marquee, hero report drift) pause while off screen so they cost nothing there. */
  function initOffscreenPause() {
    if (!('IntersectionObserver' in window)) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { e.target.style.animationPlayState = e.isIntersecting ? '' : 'paused'; });
    });
    document.querySelectorAll('.k-marquee-track, .k-index-track').forEach(function (el) { io.observe(el); });
  }

  /** Horizontal scrollers: arrow buttons move one card and loop around at either end. */
  function initScrollers() {
    document.querySelectorAll('.k-scroll-btns').forEach(function (wrap) {
      var btns = wrap.querySelectorAll('[data-scroll]');
      var track = document.getElementById(btns[0].getAttribute('aria-controls'));
      if (!track) return;
      var maxScroll = function () { return track.scrollWidth - track.clientWidth; };
      var update = function () { wrap.hidden = maxScroll() <= 2; };
      btns.forEach(function (b) {
        b.addEventListener('click', function () {
          var dir = parseInt(b.getAttribute('data-scroll'), 10);
          var max = maxScroll();
          // Loop: past the last card returns to the first, before the first jumps to the last.
          if (dir > 0 && track.scrollLeft >= max - 2) { track.scrollTo({ left: 0, behavior: 'smooth' }); return; }
          if (dir < 0 && track.scrollLeft <= 2) { track.scrollTo({ left: max, behavior: 'smooth' }); return; }
          var card = track.firstElementChild;
          var step = card ? card.getBoundingClientRect().width + parseFloat(getComputedStyle(track).columnGap || 0) : track.clientWidth;
          track.scrollBy({ left: step * dir, behavior: 'smooth' });
        });
      });
      window.addEventListener('resize', update);
      update();
      autoAdvance(track, btns[1]);
    });
  }

  /** Advance a scroller one card every 5 s (looping via the next button). Pauses while hovered, while
      focus is inside it, and while it is off screen; never runs under reduced motion. */
  function autoAdvance(track, nextBtn) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var area = track.closest('section') || track;
    var hovered = false;
    var visible = true;
    area.addEventListener('mouseenter', function () { hovered = true; });
    area.addEventListener('mouseleave', function () { hovered = false; });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) { visible = es[0].isIntersecting; }, { threshold: 0.4 }).observe(track);
    }
    window.setInterval(function () {
      if (hovered || !visible || document.hidden || area.contains(document.activeElement)) return;
      nextBtn.click();
    }, 5000);
  }

  /** Register the service worker (sw.js) that keeps images, fonts and versioned CSS/JS cached across
      visits; GitHub Pages limits browser caching to ten minutes. Skipped where unsupported. */
  function initServiceWorker() {
    if (!('serviceWorker' in navigator) || !window.isSecureContext) return;
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  /** Report Telegram bar (tablet/phone): slides up once the reader is past the report header, hides
      while the footer subscribe form is on screen, and stays closed for the session once dismissed. */
  function initSubscribeBar() {
    var bar = document.querySelector('[data-subbar]');
    var hero = document.querySelector('.r-hero');
    var footer = document.querySelector('.k-subscribe');
    if (!bar || !hero || !('IntersectionObserver' in window) || !TELEGRAM_URL) return;
    var dismissed = false;
    try { dismissed = sessionStorage.getItem('khala-subbar') === 'closed'; } catch (e) { dismissed = false; }
    var pastHero = false;
    var atFooter = false;
    var update = function () {
      // Keep the bar up while the reader is typing in it, even if they scroll to the footer.
      var show = !dismissed && ((pastHero && !atFooter) || bar.contains(document.activeElement));
      if (show) { bar.hidden = false; requestAnimationFrame(function () { bar.classList.add('is-shown'); }); }
      else bar.classList.remove('is-shown');
    };
    new IntersectionObserver(function (es) { pastHero = !es[0].isIntersecting && es[0].boundingClientRect.top < 0; update(); }).observe(hero);
    if (footer) new IntersectionObserver(function (es) { atFooter = es[0].isIntersecting; update(); }).observe(footer);
    bar.querySelector('[data-subbar-close]').addEventListener('click', function () {
      dismissed = true;
      try { sessionStorage.setItem('khala-subbar', 'closed'); } catch (e) { /* storage unavailable: dismiss for this page only */ }
      update();
    });
  }

  /** Telegram channel URL for the footer link and report CTAs. Leave empty to keep them hidden;
      set it (https://t.me/...) to switch every Telegram element on across the site. */
  var TELEGRAM_URL = 'https://t.me/KhalaReads';

  /** Point Telegram links at the channel and reveal them, once a valid URL is set above. */
  function initTelegram() {
    if (!/^https:\/\/t\.me\/[A-Za-z0-9_+\/-]+$/.test(TELEGRAM_URL)) return;
    document.querySelectorAll('[data-telegram-link]').forEach(function (a) { a.href = TELEGRAM_URL; });
    document.querySelectorAll('[data-telegram]:not([data-subbar])').forEach(function (el) { el.hidden = false; });
  }

  /** First visit: a small callout under the theme button invites the reader to try dark mode. It goes
      away after a toggle, a dismiss or 12 seconds, and is not shown again on this device. */
  function initThemeHint() {
    var btn = document.querySelector('.k-nav .k-theme-btn');
    var seen = true;
    try { seen = !!localStorage.getItem('khala-theme') || !!localStorage.getItem('khala-theme-hint'); } catch (e) { seen = true; }
    // Readers already in dark mode (system setting) have nothing to try.
    if (!btn || seen || document.documentElement.getAttribute('data-theme') === 'dark') return;
    // Up to 1080px report.css pins Contents as a bar right under the nav, where the bubble would cover it.
    if (document.querySelector('.r-rail') && window.matchMedia('(max-width: 1080px)').matches) return;
    var tip = document.createElement('div');
    tip.className = 'k-theme-hint';
    tip.setAttribute('role', 'status');
    tip.innerHTML = '<span>Try dark mode</span><button type="button" aria-label="Dismiss">&times;</button>';
    btn.parentNode.insertBefore(tip, btn.nextSibling);
    btn.classList.add('is-hinted');
    var close = function () {
      tip.remove();
      btn.classList.remove('is-hinted');
      try { localStorage.setItem('khala-theme-hint', 'seen'); } catch (e) { /* storage blocked: hint may show again */ }
    };
    tip.querySelector('button').addEventListener('click', close);
    btn.addEventListener('click', close, { once: true });
    window.setTimeout(close, 12000);
  }

  /** Flywheels place steps around a fixed-shape circle. Where long step text would spill out of the
      wheel or into another step at the current width, switch that wheel to its list layout (.is-list). */
  function initWheelFit() {
    var wheels = document.querySelectorAll('.ix-wheel');
    if (!wheels.length) return;
    var fit = function () {
      wheels.forEach(function (wheel) {
        wheel.classList.remove('is-list');
        if (getComputedStyle(wheel.querySelector('li')).position !== 'absolute') return;
        // Steps may sit past the circle's box by design; they only spill when they reach the
        // header above, the note below, the panel edges, or each other.
        var prev = wheel.previousElementSibling, next = wheel.nextElementSibling;
        var top = prev ? prev.getBoundingClientRect().bottom : -Infinity;
        var bottom = next ? next.getBoundingClientRect().top : Infinity;
        var panel = wheel.parentElement.getBoundingClientRect();
        var rects = Array.prototype.map.call(wheel.querySelectorAll('li'), function (li) { return li.getBoundingClientRect(); });
        var spills = rects.some(function (r, i) {
          if (r.top < top || r.bottom > bottom || r.left < panel.left - 1 || r.right > panel.right + 1) return true;
          return rects.some(function (o, j) {
            return j > i && r.left < o.right && o.left < r.right && r.top < o.bottom && o.top < r.bottom;
          });
        });
        if (spills) wheel.classList.add('is-list');
      });
    };
    fit();
    window.addEventListener('resize', fit);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  }

  /** Wide tables scroll sideways inside .r-table-wrap; make each wrapper keyboard-focusable and named
      so it can be scrolled with arrow keys (WCAG 2.1.1). */
  function initTableScroll() {
    document.querySelectorAll('.r-table-wrap').forEach(function (wrap, i) {
      var caption = wrap.querySelector('caption');
      var head = wrap.closest('section') ? wrap.closest('section').querySelector('h2, h3') : null;
      var name = caption ? caption.textContent.trim() : head ? head.textContent.replace(/^\s*\d+\s*/, '').trim() : 'Data';
      wrap.setAttribute('tabindex', '0');
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'Table ' + (i + 1) + ': ' + name + ' (scrolls sideways)');
    });
  }

  initThemeToggle();
  initViewportScale();
  initAnnounceAge();
  initChromeHeight();
  initButtonRoll();
  initLiveAnimations();
  initNavScrollState();
  initMobileMenu();
  initResearchIndex();
  initReportNav();
  initLiteVideos();
  initVisionScores();
  initFigureZoom();
  initOffscreenPause();
  initScrollers();
  // Service-worker registration stays on the main Khala site.
  initSubscribeBar();
  initTelegram();
  initThemeHint();
  initTableScroll();
  initScrollReveal();
  // This fork exports native SVG through privacy.js.
  initWheelFit();
})();
