(function(){
 'use strict';
 function ready(){
  function scale(view){var f=view.querySelector('iframe');if(!f)return;var factor=(view.clientWidth||1600)/1600;f.style.transform='scale('+factor+')';view.style.height=720*factor+'px'}
  function applyTheme(f){try{f.contentDocument.documentElement.dataset.theme=document.documentElement.dataset.theme||'light'}catch(e){}try{f.contentWindow.postMessage({type:'khala-theme',theme:document.documentElement.dataset.theme||'light'},'*')}catch(e){}}
  function observe(view){scale(view);var f=view.querySelector('iframe');if(f){f.addEventListener('load',function(){applyTheme(f)});applyTheme(f)}if(typeof ResizeObserver==='function')new ResizeObserver(function(){scale(view)}).observe(view)}
  document.querySelectorAll('.privacy-slide-viewport').forEach(observe);
  window.addEventListener('resize',function(){document.querySelectorAll('.privacy-slide-viewport').forEach(scale)});
  new MutationObserver(function(){document.querySelectorAll('.privacy-slide-viewport iframe').forEach(applyTheme)}).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
  window.addEventListener('message',function(e){if(!e.data||e.data.type!=='khala-anchor')return;var trusted=[...document.querySelectorAll('.privacy-slide-viewport iframe')].some(function(f){return f.contentWindow===e.source});if(!trusted)return;var target=document.getElementById(e.data.id);if(target)target.scrollIntoView({behavior:'smooth',block:'start'})});
  var articleY=0,articleHash='',returnButton=document.querySelector('.privacy-deck-return');
  function showArticle(restore){document.body.classList.remove('privacy-deck-mode');document.querySelectorAll('.privacy-slide-viewport').forEach(scale);window.scrollTo({top:restore?articleY:0,behavior:'instant'})}
  function showDeck(){document.body.classList.add('privacy-deck-mode');document.querySelectorAll('.privacy-slide-viewport').forEach(scale);window.scrollTo({top:0,behavior:'instant'})}
  document.querySelectorAll('[data-view-deck]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();articleY=window.scrollY;articleHash=location.hash;history.pushState({khalaDeck:true,articleY:articleY,articleHash:articleHash},'','#deck');showDeck()})});
  if(returnButton)returnButton.addEventListener('click',function(){history.replaceState(null,'',location.pathname+location.search+articleHash);showArticle(true)});
  window.addEventListener('popstate',function(){if(location.hash==='#deck')showDeck();else showArticle(true)});
  if(location.hash==='#deck')showDeck();
  var dialog=document.getElementById('privacy-slide-dialog'),lastFocus;
  if(!dialog){dialog=document.createElement('dialog');dialog.id='privacy-slide-dialog';dialog.className='privacy-slide-dialog';dialog.setAttribute('aria-label','Expanded research slide');dialog.innerHTML='<div class="privacy-dialog-bar"><span data-expanded-title>Khala Research</span><div><a data-expanded-svg download>Download SVG ↓</a><a data-expanded-html download>Download expanded HTML ↓</a><button data-close-slide type="button">Close ×</button></div></div><div class="privacy-expanded-scroll"><div class="privacy-slide-viewport privacy-expanded-viewport"></div></div>';document.body.append(dialog)}
  document.querySelectorAll('[data-expand-slide]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();lastFocus=a;var figure=a.closest('.privacy-slide'),svg=figure.querySelector('[download$=".svg"]'),view=dialog.querySelector('.privacy-expanded-viewport');dialog.querySelector('[data-expanded-title]').textContent=figure.querySelector('.privacy-slide-title').textContent;var sl=dialog.querySelector('[data-expanded-svg]');sl.href=svg.href;sl.download=svg.download;var hl=dialog.querySelector('[data-expanded-html]');hl.href=a.href;hl.download='khala-'+a.dataset.expandSlide+'.html';view.innerHTML='';var f=document.createElement('iframe');f.src=a.href;f.width='1600';f.height='720';f.title=figure.querySelector('.privacy-slide-title').textContent;f.scrolling='no';view.append(f);if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');observe(view)})});
  function close(){if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');dialog.querySelector('.privacy-expanded-viewport').innerHTML='';if(lastFocus)lastFocus.focus()}
  dialog.querySelector('[data-close-slide]').addEventListener('click',close);dialog.addEventListener('click',function(e){if(e.target===dialog)close()});dialog.addEventListener('close',function(){if(lastFocus)lastFocus.focus()});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();
