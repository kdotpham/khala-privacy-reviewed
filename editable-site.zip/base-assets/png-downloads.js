(function () {
  'use strict';
  var WIDTH = 1600, HEIGHT = 720, SCALE = 2;
  var figures = Array.from(document.querySelectorAll('figure.privacy-slide'));
  var payload = document.getElementById('khala-slide-data');
  var data = payload ? JSON.parse(payload.textContent) : null;
  var encoder = new TextEncoder();
  var crcTable = new Uint32Array(256);
  for (var n = 0; n < 256; n++) {
    var c = n;
    for (var k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crcTable[n] = c >>> 0;
  }
  function theme() { return document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light'; }
  function filename(figure, mode) {
    return 'khala-' + (figures.indexOf(figure) + 1) + '-' + figure.id + (mode === 'dark' ? '-dark' : '') + '.png';
  }
  async function render(figure, mode) {
    var doc, css;
    if (data) {
      var slide = data.slides.find(function (s) { return s.id === figure.id; });
      if (!slide) throw new Error('Slide content is missing.');
      doc = new DOMParser().parseFromString(slide.body, 'text/html');
      css = data.css;
    } else {
      var response = await fetch(figure.querySelector('[data-expand-slide]').href);
      if (!response.ok) throw new Error('The slide could not be loaded.');
      doc = new DOMParser().parseFromString(await response.text(), 'text/html');
      css = Array.from(doc.querySelectorAll('style')).map(function (s) { return s.textContent; }).join('\n');
    }
    var section = doc.querySelector('section.frame');
    if (!section) throw new Error('The slide frame is missing.');
    section.querySelectorAll('script').forEach(function (s) { s.remove(); });
    css += '\n*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}html,body{margin:0!important;padding:0!important;overflow:hidden!important}.frame{margin:0!important;box-shadow:none!important}';
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + WIDTH + '" height="' + HEIGHT + '" viewBox="0 0 ' + WIDTH + ' ' + HEIGHT + '"><foreignObject width="100%" height="100%"><html xmlns="http://www.w3.org/1999/xhtml" data-theme="' + mode + '"><head><style>' + css.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</style></head><body>' + new XMLSerializer().serializeToString(section) + '</body></html></foreignObject></svg>';
    var img = new Image();
    await new Promise(function (resolve, reject) {
      img.onload = resolve;
      img.onerror = function () { reject(new Error('The slide image could not be rendered.')); };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
    var canvas = document.createElement('canvas');
    canvas.width = WIDTH * SCALE; canvas.height = HEIGHT * SCALE;
    var context = canvas.getContext('2d');
    context.fillStyle = mode === 'dark' ? '#0B0E15' : '#FFFFFF';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(img, 0, 0, canvas.width, canvas.height);
    var blob = await new Promise(function (resolve) { canvas.toBlob(resolve, 'image/png'); });
    canvas.width = canvas.height = 1;
    if (!blob) throw new Error('PNG export failed.');
    return blob;
  }
  function download(blob, name) {
    var url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
  }
  async function run(button, action) {
    if (button.getAttribute('aria-disabled') === 'true') return;
    var label = button.textContent;
    button.setAttribute('aria-disabled', 'true'); button.setAttribute('aria-busy', 'true');
    try { await action(); }
    catch (error) { window.alert('PNG download failed: ' + error.message + ' Please try again.'); }
    finally { button.textContent = label; button.removeAttribute('aria-disabled'); button.removeAttribute('aria-busy'); }
  }
  function pngButton(figure, expanded) {
    var a = document.createElement('a'); a.href = '#';
    a.textContent = expanded ? 'Download PNG ↓' : 'PNG ↓';
    a.setAttribute('aria-label', 'Download PNG: ' + figure.querySelector('.privacy-slide-title').textContent);
    a.addEventListener('click', function (event) {
      event.preventDefault();
      run(a, async function () { a.textContent = 'Preparing PNG…'; var mode = theme(); download(await render(figure, mode), filename(figure, mode)); });
    });
    return a;
  }
  function crc32(bytes) {
    var c = 0xffffffff;
    for (var i = 0; i < bytes.length; i++) c = crcTable[(c ^ bytes[i]) & 255] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }
  function header(size) { var bytes = new Uint8Array(size); return {bytes: bytes, view: new DataView(bytes.buffer)}; }
  async function zip(entries) {
    var local = [], central = [], offset = 0, centralSize = 0;
    for (var i = 0; i < entries.length; i++) {
      var entry = entries[i], bytes = new Uint8Array(await entry.blob.arrayBuffer()), name = encoder.encode(entry.name), crc = crc32(bytes);
      var h = header(30), v = h.view;
      v.setUint32(0, 0x04034b50, true); v.setUint16(4, 20, true); v.setUint16(6, 0x800, true);
      v.setUint16(12, 0x21, true); v.setUint32(14, crc, true); v.setUint32(18, bytes.length, true); v.setUint32(22, bytes.length, true); v.setUint16(26, name.length, true);
      local.push(h.bytes, name, bytes);
      var ch = header(46), cv = ch.view;
      cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x800, true);
      cv.setUint16(14, 0x21, true); cv.setUint32(16, crc, true); cv.setUint32(20, bytes.length, true); cv.setUint32(24, bytes.length, true); cv.setUint16(28, name.length, true); cv.setUint32(42, offset, true);
      central.push(ch.bytes, name); centralSize += 46 + name.length; offset += 30 + name.length + bytes.length;
    }
    var end = header(22), ev = end.view;
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, entries.length, true); ev.setUint16(10, entries.length, true); ev.setUint32(12, centralSize, true); ev.setUint32(16, offset, true);
    return new Blob(local.concat(central, [end.bytes]), {type: 'application/zip'});
  }
  figures.forEach(function (figure) {
    var actions = figure.querySelector('.privacy-slide-actions');
    if (actions) actions.insertBefore(pngButton(figure, false), actions.firstChild);
    figure.querySelector('[data-expand-slide]').addEventListener('click', function () {
      var bar = document.querySelector('#privacy-slide-dialog .privacy-dialog-bar>div');
      var old = bar.querySelector('[data-expanded-png]'); if (old) old.remove();
      var button = pngButton(figure, true); button.setAttribute('data-expanded-png', ''); bar.insertBefore(button, bar.firstChild);
    });
  });
  var downloads = document.querySelector('.privacy-downloads') || document.querySelector('.privacy-deck-nav');
  if (downloads) {
    var all = document.createElement('a'); all.href = '#'; all.className = 'privacy-deck-link'; all.textContent = 'Download all PNGs ↓';
    all.addEventListener('click', function (event) {
      event.preventDefault();
      run(all, async function () {
        var mode = theme(), entries = [];
        for (var i = 0; i < figures.length; i++) {
          all.textContent = 'Preparing PNG ' + (i + 1) + ' / ' + figures.length + '…';
          entries.push({name: filename(figures[i], mode), blob: await render(figures[i], mode)});
          await new Promise(function (resolve) { setTimeout(resolve, 0); });
        }
        all.textContent = 'Preparing ZIP…'; download(await zip(entries), 'khala-slides-png' + (mode === 'dark' ? '-dark' : '') + '.zip');
      });
    });
    downloads.appendChild(all);
  }
})();
